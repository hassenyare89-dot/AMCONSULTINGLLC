
REVOKE EXECUTE ON FUNCTION public.claim_first_admin() FROM authenticated;
