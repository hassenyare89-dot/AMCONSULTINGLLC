import { createFileRoute } from "@tanstack/react-router";
import { Process } from "@/components/site/Process";

export const Route = createFileRoute("/process")({
  head: () => ({
    meta: [
      { title: "Our Process | AMCONSULTINGLLC" },
      {
        name: "description",
        content:
          "Our 4-step dispatching process: consult, plan, dispatch, and deliver — designed for predictable hauling outcomes.",
      },
      { property: "og:title", content: "Our Process | AMCONSULTINGLLC" },
      {
        property: "og:description",
        content: "A clear 4-step workflow for reliable dump truck dispatching and hauling.",
      },
    ],
    links: [{ rel: "canonical", href: "/process" }],
  }),
  component: () => (
    <div className="pt-16">
      <Process />
    </div>
  ),
});
