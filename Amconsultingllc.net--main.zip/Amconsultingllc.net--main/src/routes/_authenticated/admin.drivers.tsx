import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import {
  listDrivers,
  updateDriverStatus,
  getAdminStatus,
  claimFirstAdmin,
  type DriverRow,
} from "@/lib/admin.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Download,
  Loader2,
  LogOut,
  RefreshCw,
  Search,
  Shield,
} from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/drivers")({
  head: () => ({
    meta: [
      { title: "Driver registrations | Admin" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: AdminDriversPage,
});

const TRUCK_TYPES = [
  { v: "tandem", l: "Tandem" },
  { v: "quad-axle", l: "Quad-axle" },
  { v: "side-dump", l: "Side dump" },
  { v: "super-dump", l: "Super dump" },
  { v: "other", l: "Other" },
];
const AVAILABILITY = [
  { v: "full-time", l: "Full-time" },
  { v: "part-time", l: "Part-time" },
  { v: "on-call", l: "On-call" },
];
const STATUSES = ["new", "reviewed", "approved", "rejected"] as const;

function statusVariant(s: string) {
  switch (s) {
    case "approved":
      return "bg-emerald-100 text-emerald-800 border-emerald-200";
    case "rejected":
      return "bg-red-100 text-red-800 border-red-200";
    case "reviewed":
      return "bg-amber-100 text-amber-800 border-amber-200";
    default:
      return "bg-blue-100 text-blue-800 border-blue-200";
  }
}

function csvEscape(v: unknown) {
  const s = v == null ? "" : String(v);
  if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}
function downloadCsv(rows: DriverRow[]) {
  const headers = [
    "id",
    "created_at",
    "status",
    "owner_name",
    "company_name",
    "email",
    "phone",
    "dot_number",
    "mc_number",
    "truck_type",
    "truck_count",
    "service_area",
    "availability",
    "notes",
  ];
  const lines = [headers.join(",")];
  for (const r of rows) lines.push(headers.map((h) => csvEscape((r as any)[h])).join(","));
  const blob = new Blob(["\uFEFF" + lines.join("\n")], {
    type: "text/csv;charset=utf-8;",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `driver-registrations-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function AdminDriversPage() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const list = useServerFn(listDrivers);
  const status = useServerFn(getAdminStatus);
  const claim = useServerFn(claimFirstAdmin);
  const mutateStatus = useServerFn(updateDriverStatus);

  const [search, setSearch] = useState("");
  const [availability, setAvailability] = useState<string>("all");
  const [truckType, setTruckType] = useState<string>("all");
  const [serviceArea, setServiceArea] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const statusQuery = useQuery({
    queryKey: ["admin-status"],
    queryFn: () => status(),
  });

  const isAdmin = statusQuery.data?.isAdmin ?? false;

  const driversQuery = useQuery({
    queryKey: ["drivers", { availability, truckType, serviceArea, search }],
    enabled: isAdmin,
    queryFn: () =>
      list({
        data: {
          search,
          availability: availability === "all" ? "" : availability,
          truckType: truckType === "all" ? "" : truckType,
          serviceArea,
        },
      }),
  });

  const rows = useMemo(() => {
    const r = driversQuery.data?.rows ?? [];
    return statusFilter === "all" ? r : r.filter((x) => x.status === statusFilter);
  }, [driversQuery.data, statusFilter]);

  const claimMutation = useMutation({
    mutationFn: () => claim(),
    onSuccess: (res) => {
      if (res?.claimed) {
        toast.success("Admin access granted");
        qc.invalidateQueries({ queryKey: ["admin-status"] });
      } else {
        toast.error("An admin already exists — ask them to grant you access.");
      }
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  const setStatusMutation = useMutation({
    mutationFn: (v: { id: string; status: (typeof STATUSES)[number] }) =>
      mutateStatus({ data: v }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["drivers"] }),
    onError: (e: any) => toast.error(e?.message ?? "Update failed"),
  });

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  // Loading or not-admin states
  if (statusQuery.isLoading) {
    return (
      <div className="min-h-screen pt-28 pb-16 px-4 flex items-center justify-center text-muted-foreground">
        <Loader2 className="w-5 h-5 animate-spin mr-2" /> Loading…
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen pt-28 pb-16 px-4 flex items-center justify-center">
        <div className="max-w-md w-full rounded-2xl border border-border bg-card p-8 text-center">
          <Shield className="w-10 h-10 mx-auto text-navy" />
          <h1 className="mt-4 text-xl font-bold text-navy">Admin access required</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Your account ({statusQuery.data?.email}) is signed in but isn't an
            admin yet.
          </p>
          {!statusQuery.data?.adminExists ? (
            <Button
              className="mt-6 bg-navy text-white hover:bg-navy/90"
              onClick={() => claimMutation.mutate()}
              disabled={claimMutation.isPending}
            >
              {claimMutation.isPending && (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              )}
              Claim admin (first user)
            </Button>
          ) : (
            <p className="mt-6 text-sm text-muted-foreground">
              Contact an existing admin to be added.
            </p>
          )}
          <Button variant="ghost" className="mt-3 w-full" onClick={signOut}>
            <LogOut className="w-4 h-4 mr-2" /> Sign out
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-16 bg-secondary/20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-navy">Driver registrations</h1>
            <p className="text-sm text-muted-foreground mt-1">
              {driversQuery.data?.rows.length ?? 0} total · {rows.length} shown
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => driversQuery.refetch()}
              disabled={driversQuery.isFetching}
            >
              <RefreshCw
                className={`w-4 h-4 mr-2 ${driversQuery.isFetching ? "animate-spin" : ""}`}
              />
              Refresh
            </Button>
            <Button
              onClick={() => downloadCsv(rows)}
              disabled={rows.length === 0}
              className="bg-brand-green text-navy hover:bg-brand-green/90"
            >
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
            <Button variant="ghost" onClick={signOut}>
              <LogOut className="w-4 h-4 mr-2" /> Sign out
            </Button>
          </div>
        </div>

        {/* Filters */}
        <div className="mt-6 grid gap-3 md:grid-cols-5 rounded-xl border border-border bg-card p-4">
          <div className="md:col-span-2">
            <Label htmlFor="q" className="text-xs">
              Search owner / company / email / DOT / MC
            </Label>
            <div className="relative mt-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="q"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="e.g. 1234567 or Acme"
                className="pl-9"
              />
            </div>
          </div>
          <div>
            <Label className="text-xs">Service area</Label>
            <Input
              value={serviceArea}
              onChange={(e) => setServiceArea(e.target.value)}
              placeholder="Atlanta"
              className="mt-1"
            />
          </div>
          <div>
            <Label className="text-xs">Truck type</Label>
            <Select value={truckType} onValueChange={setTruckType}>
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="All" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All types</SelectItem>
                {TRUCK_TYPES.map((t) => (
                  <SelectItem key={t.v} value={t.v}>
                    {t.l}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Availability</Label>
            <Select value={availability} onValueChange={setAvailability}>
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="All" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                {AVAILABILITY.map((t) => (
                  <SelectItem key={t.v} value={t.v}>
                    {t.l}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="md:col-span-5 flex items-center gap-2">
            <Label className="text-xs mr-2">Status</Label>
            {(["all", ...STATUSES] as const).map((s) => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className={`px-3 py-1 rounded-full text-xs border transition ${
                  statusFilter === s
                    ? "bg-navy text-white border-navy"
                    : "bg-background text-foreground hover:bg-secondary"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Table */}
        <div className="mt-6 rounded-xl border border-border bg-card overflow-hidden">
          {driversQuery.isLoading ? (
            <div className="p-10 text-center text-muted-foreground">
              <Loader2 className="w-5 h-5 animate-spin inline mr-2" /> Loading registrations…
            </div>
          ) : rows.length === 0 ? (
            <div className="p-10 text-center text-muted-foreground">
              No registrations match the current filters.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-secondary/60 text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <tr>
                    <th className="px-4 py-3">Received</th>
                    <th className="px-4 py-3">Owner</th>
                    <th className="px-4 py-3">Contact</th>
                    <th className="px-4 py-3">DOT / MC</th>
                    <th className="px-4 py-3">Truck</th>
                    <th className="px-4 py-3">Service area</th>
                    <th className="px-4 py-3">Availability</th>
                    <th className="px-4 py-3">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.id} className="border-t border-border align-top">
                      <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">
                        {new Date(r.created_at).toLocaleString()}
                      </td>
                      <td className="px-4 py-3">
                        <div className="font-medium text-navy">{r.owner_name}</div>
                        {r.company_name && (
                          <div className="text-xs text-muted-foreground">
                            {r.company_name}
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <a
                          href={`mailto:${r.email}`}
                          className="text-navy hover:underline block"
                        >
                          {r.email}
                        </a>
                        <a
                          href={`tel:${r.phone}`}
                          className="text-xs text-muted-foreground hover:underline"
                        >
                          {r.phone}
                        </a>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div>DOT {r.dot_number}</div>
                        {r.mc_number && (
                          <div className="text-xs text-muted-foreground">
                            MC {r.mc_number}
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        {r.truck_type}
                        <div className="text-xs text-muted-foreground">
                          {r.truck_count} truck{r.truck_count === 1 ? "" : "s"}
                        </div>
                      </td>
                      <td className="px-4 py-3">{r.service_area}</td>
                      <td className="px-4 py-3 capitalize">{r.availability}</td>
                      <td className="px-4 py-3">
                        <Select
                          value={r.status}
                          onValueChange={(v) =>
                            setStatusMutation.mutate({
                              id: r.id,
                              status: v as (typeof STATUSES)[number],
                            })
                          }
                        >
                          <SelectTrigger className={`h-8 w-[130px] ${statusVariant(r.status)}`}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {STATUSES.map((s) => (
                              <SelectItem key={s} value={s}>
                                {s}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
