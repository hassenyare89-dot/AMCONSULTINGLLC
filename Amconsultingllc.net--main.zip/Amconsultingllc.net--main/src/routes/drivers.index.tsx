import { createFileRoute } from "@tanstack/react-router";
import { DriverRegistration } from "@/components/site/DriverRegistration";

export const Route = createFileRoute("/drivers/")({
  head: () => ({
    meta: [
      { title: "Driver Registration | AMCONSULTINGLLC" },
      {
        name: "description",
        content:
          "Owner-operators and dump truck fleets — register with our dispatch team to receive consistent hauling work in your service area.",
      },
      { property: "og:title", content: "Driver Registration | AMCONSULTINGLLC" },
      {
        property: "og:description",
        content:
          "Register your dump trucks with AMCONSULTINGLLC dispatch. DOT, truck type, and service area onboarding.",
      },
    ],
    links: [{ rel: "canonical", href: "/drivers" }],
  }),
  component: () => (
    <div className="pt-16">
      <DriverRegistration />
    </div>
  ),
});
