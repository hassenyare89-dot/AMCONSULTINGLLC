import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  CheckCircle2,
  Clock,
  Loader2,
  XCircle,
  ShieldCheck,
  AlertTriangle,
  ClipboardList,
  Truck,
  MapPin,
  Phone,
  Mail,
} from "lucide-react";
import { CONTACT } from "@/lib/contact";
import { Button } from "@/components/ui/button";
import { SectionHeader } from "@/components/site/Services";

type Registration = {
  id: string;
  status: "new" | "reviewed" | "approved" | "rejected" | string;
  owner_name: string;
  company_name: string | null;
  email: string;
  dot_number: string;
  mc_number: string | null;
  truck_type: string;
  truck_count: number;
  service_area: string;
  availability: string;
  created_at: string;
};

type Search = { id?: string; email?: string };

const TRUCK_TYPE_LABELS: Record<string, string> = {
  tandem: "Tandem",
  "quad-axle": "Quad-axle",
  "side-dump": "Side dump",
  "super-dump": "Super dump",
  other: "Other",
};

const AVAILABILITY_LABELS: Record<string, string> = {
  "full-time": "Full-time",
  "part-time": "Part-time",
  "on-call": "On-call / as-needed",
};

const STATUS_META: Record<
  string,
  { label: string; description: string; tone: string; Icon: typeof CheckCircle2 }
> = {
  new: {
    label: "Received",
    description:
      "We've received your registration and it's in our queue. A dispatcher will verify your details shortly.",
    tone: "bg-sky-500/15 text-sky-700",
    Icon: Clock,
  },
  reviewed: {
    label: "Under review",
    description:
      "Our team is verifying your DOT/MC, insurance, and authority. Have your COI and W-9 ready.",
    tone: "bg-amber-500/15 text-amber-700",
    Icon: ShieldCheck,
  },
  approved: {
    label: "Approved",
    description:
      "You're approved! A dispatcher will reach out to schedule your first load.",
    tone: "bg-emerald-500/15 text-emerald-700",
    Icon: CheckCircle2,
  },
  rejected: {
    label: "Not a fit right now",
    description:
      "We weren't able to onboard you at this time. Please contact dispatch if you'd like more detail.",
    tone: "bg-rose-500/15 text-rose-700",
    Icon: XCircle,
  },
};

export const Route = createFileRoute("/drivers/status")({
  validateSearch: (search: Record<string, unknown>): Search => ({
    id: typeof search.id === "string" ? search.id : undefined,
    email: typeof search.email === "string" ? search.email : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Registration Status | AMCONSULTINGLLC" },
      {
        name: "description",
        content:
          "Check the status of your AMCONSULTINGLLC driver registration and see your submission details.",
      },
      { name: "robots", content: "noindex" },
    ],
    links: [{ rel: "canonical", href: "/drivers/status" }],
  }),
  component: StatusPage,
});

function StatusPage() {
  const { id, email } = Route.useSearch();
  const [state, setState] = useState<
    | { kind: "idle" }
    | { kind: "loading" }
    | { kind: "error"; message: string }
    | { kind: "ok"; data: Registration }
  >({ kind: "idle" });
  const [emailInput, setEmailInput] = useState(email ?? "");
  const [idInput, setIdInput] = useState(id ?? "");

  async function load(lookupId: string, lookupEmail: string) {
    setState({ kind: "loading" });
    try {
      const res = await fetch(
        `/api/public/driver-status?id=${encodeURIComponent(lookupId)}&email=${encodeURIComponent(lookupEmail)}`,
      );
      const json = (await res.json().catch(() => ({}))) as {
        ok?: boolean;
        registration?: Registration;
        error?: string;
      };
      if (!res.ok || !json.ok || !json.registration) {
        setState({
          kind: "error",
          message:
            res.status === 404
              ? "We couldn't find a registration matching that link. Double-check the email."
              : json.error || "Something went wrong. Please try again.",
        });
        return;
      }
      setState({ kind: "ok", data: json.registration });
    } catch {
      setState({ kind: "error", message: "Network error. Please try again." });
    }
  }

  useEffect(() => {
    if (id && email) load(id, email);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, email]);

  return (
    <div className="pt-16">
      <section className="relative py-20 sm:py-28 bg-background">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
          <SectionHeader
            eyebrow="Driver portal"
            title="Registration status"
            subtitle="Check where your application stands and see what we have on file."
          />

          {state.kind === "loading" ? (
            <div className="mt-12 flex items-center justify-center gap-3 text-muted-foreground">
              <Loader2 className="w-5 h-5 animate-spin" /> Loading your status…
            </div>
          ) : null}

          {state.kind === "ok" ? <StatusCard data={state.data} /> : null}

          {(state.kind === "error" || state.kind === "idle") && (
            <motion.form
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              onSubmit={(e) => {
                e.preventDefault();
                if (!idInput || !emailInput) return;
                load(idInput.trim(), emailInput.trim());
              }}
              className="mt-10 rounded-3xl bg-card border border-border shadow-[var(--shadow-card)] p-6 sm:p-8"
            >
              {state.kind === "error" ? (
                <div className="mb-5 flex items-start gap-3 rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-800">
                  <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
                  <span>{state.message}</span>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground mb-5">
                  Paste the link from your confirmation email, or enter the details below to look up
                  your registration.
                </p>
              )}

              <div className="grid sm:grid-cols-2 gap-4">
                <label className="block">
                  <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Registration ID
                  </span>
                  <input
                    type="text"
                    value={idInput}
                    onChange={(e) => setIdInput(e.target.value)}
                    placeholder="00000000-0000-0000-0000-000000000000"
                    className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2 text-sm font-mono focus-visible:focus-brand"
                  />
                </label>
                <label className="block">
                  <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Email used to register
                  </span>
                  <input
                    type="email"
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    placeholder="you@example.com"
                    className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2 text-sm focus-visible:focus-brand"
                  />
                </label>
              </div>
              <Button
                type="submit"
                className="mt-5 bg-brand-green hover:bg-brand-green/90 text-navy shadow-[var(--shadow-glow)]"
                disabled={!idInput || !emailInput}
              >
                Check status
              </Button>

              <div className="mt-6 text-center text-sm text-muted-foreground">
                Don't have a registration yet?{" "}
                <Link
                  to="/drivers"
                  className="underline decoration-brand-green decoration-2 underline-offset-4 hover:text-navy rounded"
                >
                  Register your fleet
                </Link>
              </div>
            </motion.form>
          )}
        </div>
      </section>
    </div>
  );
}

function StatusCard({ data }: { data: Registration }) {
  const meta = STATUS_META[data.status] ?? STATUS_META.new;
  const Icon = meta.Icon;
  const submitted = new Date(data.created_at).toLocaleString();

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45 }}
      className="mt-10 rounded-3xl bg-card border border-border shadow-[var(--shadow-card)] p-6 sm:p-8"
    >
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Current status
          </div>
          <div
            className={`mt-2 inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-sm font-semibold ${meta.tone}`}
          >
            <Icon className="w-4 h-4" /> {meta.label}
          </div>
          <p className="mt-3 text-sm text-muted-foreground max-w-md">{meta.description}</p>
        </div>
        <div className="text-xs text-muted-foreground sm:text-right">
          <div>Submitted</div>
          <div className="font-semibold text-navy">{submitted}</div>
        </div>
      </div>

      <div className="mt-6 flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-muted-foreground">
        <ClipboardList className="w-4 h-4" /> Submission on file
      </div>
      <dl className="mt-4 grid sm:grid-cols-2 gap-x-8 gap-y-4">
        <Row label="Owner / Driver" value={data.owner_name} />
        {data.company_name ? <Row label="Company" value={data.company_name} /> : null}
        <Row label="Email" value={data.email} />
        <Row label="DOT Number" value={data.dot_number} mono />
        <Row label="MC Number" value={data.mc_number || "—"} mono />
        <Row
          label="Truck Type"
          value={TRUCK_TYPE_LABELS[data.truck_type] ?? data.truck_type}
          icon={<Truck className="w-4 h-4" />}
        />
        <Row label="Number of Trucks" value={String(data.truck_count)} />
        <Row
          label="Service Area"
          value={data.service_area}
          icon={<MapPin className="w-4 h-4" />}
        />
        <Row
          label="Availability"
          value={AVAILABILITY_LABELS[data.availability] ?? data.availability}
        />
      </dl>

      <div className="mt-8 grid sm:grid-cols-2 gap-3">
        <Button
          asChild
          className="bg-brand-green hover:bg-brand-green/90 text-navy shadow-[var(--shadow-glow)]"
        >
          <a href={`tel:${CONTACT.phoneE164}`}>
            <Phone className="w-4 h-4 mr-2" /> Call dispatch
          </a>
        </Button>
        <Button asChild variant="outline">
          <a href="mailto:info@amconsultingllc.net">
            <Mail className="w-4 h-4 mr-2" /> Email us
          </a>
        </Button>
      </div>
    </motion.div>
  );
}

function Row({
  label,
  value,
  mono,
  icon,
}: {
  label: string;
  value: string;
  mono?: boolean;
  icon?: React.ReactNode;
}) {
  return (
    <div>
      <dt className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        {label}
      </dt>
      <dd
        className={`mt-1 flex items-center gap-2 text-base font-semibold text-navy ${
          mono ? "font-mono tracking-wide" : ""
        }`}
      >
        {icon ? (
          <span className="text-brand-green" aria-hidden="true">
            {icon}
          </span>
        ) : null}
        <span className="break-words">{value}</span>
      </dd>
    </div>
  );
}
