import { createFileRoute } from "@tanstack/react-router";
import { About } from "@/components/site/About";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About | AMCONSULTINGLLC" },
      {
        name: "description",
        content:
          "Learn about AMCONSULTINGLLC — a hauling and dispatching partner committed to keeping contractors on schedule.",
      },
      { property: "og:title", content: "About | AMCONSULTINGLLC" },
      {
        property: "og:description",
        content:
          "Built by hauling professionals to keep your project moving on time and on budget.",
      },
    ],
    links: [{ rel: "canonical", href: "/about" }],
  }),
  component: () => (
    <div className="pt-16">
      <About />
    </div>
  ),
});
