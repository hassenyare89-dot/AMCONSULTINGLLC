import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { CONTACT } from "@/lib/contact";

const DriverSchema = z.object({
  ownerName: z.string().trim().min(1).max(100),
  companyName: z.string().trim().max(150).optional().or(z.literal("")),
  email: z.string().trim().email().max(255),
  phone: z.string().trim().min(7).max(30),
  dotNumber: z.string().trim().min(4).max(20).regex(/^[0-9]+$/, "DOT number must be digits"),
  mcNumber: z.string().trim().max(20).optional().or(z.literal("")),
  truckType: z.enum([
    "tandem",
    "quad-axle",
    "side-dump",
    "super-dump",
    "other",
  ]),
  truckCount: z.coerce.number().int().min(1).max(500),
  serviceArea: z.string().trim().min(2).max(200),
  availability: z.enum(["full-time", "part-time", "on-call"]),
  notes: z.string().trim().max(1500).optional().or(z.literal("")),
  website: z.string().max(0).optional().or(z.literal("")),
  ts: z.number().int().nonnegative(),
});

const HITS = new Map<string, { count: number; reset: number }>();
const WINDOW_MS = 60_000;
const MAX_PER_WINDOW = 5;

function rateLimit(ip: string): boolean {
  const now = Date.now();
  const entry = HITS.get(ip);
  if (!entry || entry.reset < now) {
    HITS.set(ip, { count: 1, reset: now + WINDOW_MS });
    return true;
  }
  entry.count += 1;
  return entry.count <= MAX_PER_WINDOW;
}

function escapeHtml(s: string) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

export const Route = createFileRoute("/api/public/driver")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const ip =
          request.headers.get("cf-connecting-ip") ||
          request.headers.get("x-forwarded-for")?.split(",")[0].trim() ||
          "unknown";

        if (!rateLimit(ip)) {
          return Response.json(
            { ok: false, error: "Too many requests. Please try again shortly." },
            { status: 429 },
          );
        }

        let body: unknown;
        try {
          body = await request.json();
        } catch {
          return Response.json({ ok: false, error: "Invalid JSON" }, { status: 400 });
        }

        const parsed = DriverSchema.safeParse(body);
        if (!parsed.success) {
          return Response.json(
            { ok: false, error: parsed.error.issues[0]?.message || "Validation failed" },
            { status: 400 },
          );
        }
        const data = parsed.data;

        if (data.website && data.website.length > 0) {
          return Response.json({ ok: true });
        }
        const elapsed = Date.now() - data.ts;
        if (elapsed < 2000 || elapsed > 1000 * 60 * 60) {
          return Response.json({ ok: true });
        }

        const RESEND_API_KEY = process.env.RESEND_API_KEY;
        const TO = process.env.LEAD_RECIPIENT_EMAIL || "info@amconsultingllc.net";
        const FROM = process.env.LEAD_FROM_EMAIL || "AMCONSULTINGLLC <onboarding@resend.dev>";

        const subject = `New driver registration — ${data.ownerName} (DOT ${data.dotNumber})`;
        const row = (label: string, value: string) =>
          `<tr><td style="padding:8px 0;color:#64748b;width:160px;vertical-align:top">${label}</td><td><strong>${escapeHtml(value)}</strong></td></tr>`;

        const html = `
          <div style="font-family:Inter,Arial,sans-serif;max-width:620px;margin:auto;color:#0f172a">
            <h2 style="color:#01257D;margin:0 0 12px">New driver registration</h2>
            <p style="color:#475569;margin:0 0 20px">A truck owner just registered through amconsultingllc.net</p>
            <table style="width:100%;border-collapse:collapse;font-size:14px">
              ${row("Owner / Driver", data.ownerName)}
              ${row("Company", data.companyName || "—")}
              ${row("Email", data.email)}
              ${row("Phone", data.phone)}
              ${row("DOT Number", data.dotNumber)}
              ${row("MC Number", data.mcNumber || "—")}
              ${row("Truck Type", data.truckType)}
              ${row("Truck Count", String(data.truckCount))}
              ${row("Service Area", data.serviceArea)}
              ${row("Availability", data.availability)}
              ${row("Notes", data.notes || "—")}
              ${row("IP", ip)}
            </table>
            <hr style="border:none;border-top:1px solid #e2e8f0;margin:24px 0" />
            <p style="font-size:12px;color:#94a3b8">AMCONSULTINGLLC driver registration</p>
          </div>`;

        // Persist to database regardless of email delivery configuration
        let registrationId: string | null = null;
        try {
          const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
          const { data: inserted, error: dbError } = await supabaseAdmin
            .from("driver_registrations")
            .insert({
              owner_name: data.ownerName,
              company_name: data.companyName || null,
              email: data.email,
              phone: data.phone,
              dot_number: data.dotNumber,
              mc_number: data.mcNumber || null,
              truck_type: data.truckType,
              truck_count: data.truckCount,
              service_area: data.serviceArea,
              availability: data.availability,
              notes: data.notes || null,
              ip,
            })
            .select("id")
            .single();
          if (dbError) console.error("[driver] db insert failed", dbError);
          else registrationId = inserted?.id ?? null;
        } catch (err) {
          console.error("[driver] db insert exception", err);
        }

        const base =
          process.env.PUBLIC_SITE_URL ||
          (() => {
            try {
              return new URL(request.url).origin;
            } catch {
              return "";
            }
          })();
        const statusUrl = registrationId
          ? `${base}/drivers/status?id=${encodeURIComponent(registrationId)}&email=${encodeURIComponent(data.email)}`
          : null;


        if (!RESEND_API_KEY) {
          console.warn("[driver] RESEND_API_KEY not set; logging only", {
            to: TO,
            owner: data.ownerName,
            dot: data.dotNumber,
          });
          return Response.json({ ok: true, delivered: false, id: registrationId, statusUrl });

        }

        const TRUCK_TYPE_LABELS: Record<string, string> = {
          tandem: "Tandem",
          "quad-axle": "Quad-axle",
          "side-dump": "Side dump",
          "super-dump": "Super dump",
          other: "Other",
        };
        const AVAILABILITY_LABELS: Record<string, string> = {
          "full-time": "Full-time",
          "part-time": "Part-time",
          "on-call": "On-call / as-needed",
        };

        const driverSubject = "Your AMCONSULTINGLLC registration was received";
        const driverHtml = `
          <div style="font-family:Inter,Arial,sans-serif;max-width:560px;margin:auto;color:#0f172a;background:#ffffff;padding:32px 24px">
            <h2 style="color:#01257D;margin:0 0 8px">You're registered, ${escapeHtml(data.ownerName)}!</h2>
            <p style="color:#475569;margin:0 0 20px;font-size:15px">
              Thanks for registering your fleet with AMCONSULTINGLLC dispatch. Our team will review your submission and reach out within one business day.
            </p>

            <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:12px;padding:16px 20px;margin:20px 0">
              <div style="font-size:11px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:#64748b;margin-bottom:10px">Your submission</div>
              <table style="width:100%;border-collapse:collapse;font-size:14px">
                ${row("DOT Number", data.dotNumber)}
                ${row("MC Number", data.mcNumber || "—")}
                ${row("Truck Type", TRUCK_TYPE_LABELS[data.truckType] ?? data.truckType)}
                ${row("Trucks", String(data.truckCount))}
                ${row("Service Area", data.serviceArea)}
                ${row("Availability", AVAILABILITY_LABELS[data.availability] ?? data.availability)}
              </table>
            </div>

            <div style="font-size:11px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:#64748b;margin:24px 0 10px">What happens next</div>
            <ol style="padding-left:20px;margin:0;color:#0f172a;font-size:14px;line-height:1.6">
              <li><strong>Verification</strong> — we'll verify your DOT/MC, authority, and insurance. Have your COI and W-9 ready.</li>
              <li><strong>Dispatch call</strong> — a dispatcher will confirm equipment, rates, and your service area.</li>
              <li><strong>First load</strong> — once onboarded, you'll start receiving consistent hauling work.</li>
            </ol>

            <div style="margin-top:28px;padding:16px;background:#01257D;border-radius:12px;text-align:center">
              <div style="color:#ffffff;font-size:13px;margin-bottom:6px">Need to reach dispatch sooner?</div>
              <a href="tel:${CONTACT.phoneE164}" style="color:#ffffff;font-weight:700;text-decoration:none;font-size:16px">Call ${CONTACT.phone}</a>
            </div>

            ${
              statusUrl
                ? `<div style="margin-top:16px;padding:18px;border:1px solid #E2E8F0;border-radius:12px;text-align:center">
                    <div style="font-size:13px;color:#475569;margin-bottom:10px">Track your application anytime</div>
                    <a href="${statusUrl}" style="display:inline-block;background:#0DAA77;color:#ffffff;font-weight:700;text-decoration:none;font-size:14px;padding:10px 18px;border-radius:8px">Check submission status</a>
                    <div style="font-size:11px;color:#94a3b8;margin-top:10px;word-break:break-all">${statusUrl}</div>
                  </div>`
                : ""
            }


            <hr style="border:none;border-top:1px solid #e2e8f0;margin:28px 0 16px" />
            <p style="font-size:12px;color:#94a3b8;margin:0">
              You're receiving this because you registered as an owner-operator at amconsultingllc.net. If this wasn't you, reply to let us know.
            </p>
          </div>`;

        async function sendMail(opts: {
          to: string;
          subject: string;
          html: string;
          replyTo?: string;
        }) {
          return fetch("https://api.resend.com/emails", {
            method: "POST",
            headers: {
              Authorization: `Bearer ${RESEND_API_KEY}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              from: FROM,
              to: [opts.to],
              ...(opts.replyTo ? { reply_to: opts.replyTo } : {}),
              subject: opts.subject,
              html: opts.html,
            }),
          });
        }


        try {
          const [internalRes, driverRes] = await Promise.all([
            sendMail({ to: TO, subject, html, replyTo: data.email }),
            sendMail({
              to: data.email,
              subject: driverSubject,
              html: driverHtml,
              replyTo: TO,
            }),
          ]);

          if (!internalRes.ok) {
            const errText = await internalRes.text();
            console.error("[driver] Resend internal error", internalRes.status, errText);
            return Response.json({
              ok: true,
              delivered: false,
              driverConfirmation: false,
              id: registrationId,
              statusUrl,
            });
          }

          let driverDelivered = driverRes.ok;
          if (!driverRes.ok) {
            const errText = await driverRes.text();
            console.error("[driver] Resend driver-confirmation error", driverRes.status, errText);
          }

          return Response.json({
            ok: true,
            delivered: true,
            driverConfirmation: driverDelivered,
            id: registrationId,
            statusUrl,
          });
        } catch (err) {
          console.error("[driver] send failed", err);
          return Response.json({ ok: true, delivered: false, id: registrationId, statusUrl });
        }
      },
    },
  },
});
