import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const LeadSchema = z.object({
  name: z.string().trim().min(1).max(100),
  email: z.string().trim().email().max(255),
  phone: z.string().trim().max(30).optional().or(z.literal("")),
  message: z.string().trim().min(1).max(2000),
  // Spam protection
  website: z.string().max(0).optional().or(z.literal("")), // honeypot — must be empty
  ts: z.number().int().nonnegative(),
});

// Simple in-memory rate limit (per-instance; resets on cold start)
const HITS = new Map<string, { count: number; reset: number }>();
const WINDOW_MS = 60_000;
const MAX_PER_WINDOW = 5;

function rateLimit(ip: string): boolean {
  const now = Date.now();
  const entry = HITS.get(ip);
  if (!entry || entry.reset < now) {
    HITS.set(ip, { count: 1, reset: now + WINDOW_MS });
    return true;
  }
  entry.count += 1;
  if (entry.count > MAX_PER_WINDOW) return false;
  return true;
}

function escapeHtml(s: string) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

export const Route = createFileRoute("/api/public/contact")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const ip =
          request.headers.get("cf-connecting-ip") ||
          request.headers.get("x-forwarded-for")?.split(",")[0].trim() ||
          "unknown";

        if (!rateLimit(ip)) {
          return Response.json(
            { ok: false, error: "Too many requests. Please try again shortly." },
            { status: 429 },
          );
        }

        let body: unknown;
        try {
          body = await request.json();
        } catch {
          return Response.json({ ok: false, error: "Invalid JSON" }, { status: 400 });
        }

        const parsed = LeadSchema.safeParse(body);
        if (!parsed.success) {
          return Response.json(
            { ok: false, error: "Validation failed" },
            { status: 400 },
          );
        }

        const data = parsed.data;

        // Honeypot tripped
        if (data.website && data.website.length > 0) {
          return Response.json({ ok: true });
        }

        // Time trap: form must take at least 2 seconds to fill
        const elapsed = Date.now() - data.ts;
        if (elapsed < 2000 || elapsed > 1000 * 60 * 60) {
          return Response.json({ ok: true });
        }

        const RESEND_API_KEY = process.env.RESEND_API_KEY;
        const TO = process.env.LEAD_RECIPIENT_EMAIL || "info@amconsultingllc.net";
        const FROM = process.env.LEAD_FROM_EMAIL || "AMCONSULTINGLLC <onboarding@resend.dev>";

        const subject = `New lead — ${data.name}`;
        const html = `
          <div style="font-family:Inter,Arial,sans-serif;max-width:560px;margin:auto;color:#0f172a">
            <h2 style="color:#072A6C;margin:0 0 12px">New contact form submission</h2>
            <p style="color:#475569;margin:0 0 20px">A new lead came in from amconsultingllc.net</p>
            <table style="width:100%;border-collapse:collapse;font-size:14px">
              <tr><td style="padding:8px 0;color:#64748b;width:120px">Name</td><td><strong>${escapeHtml(data.name)}</strong></td></tr>
              <tr><td style="padding:8px 0;color:#64748b">Email</td><td><a href="mailto:${escapeHtml(data.email)}">${escapeHtml(data.email)}</a></td></tr>
              <tr><td style="padding:8px 0;color:#64748b">Phone</td><td>${escapeHtml(data.phone || "—")}</td></tr>
              <tr><td style="padding:8px 0;color:#64748b;vertical-align:top">Message</td><td style="white-space:pre-wrap">${escapeHtml(data.message)}</td></tr>
              <tr><td style="padding:8px 0;color:#64748b">IP</td><td style="color:#94a3b8">${escapeHtml(ip)}</td></tr>
            </table>
            <hr style="border:none;border-top:1px solid #e2e8f0;margin:24px 0" />
            <p style="font-size:12px;color:#94a3b8">AMCONSULTINGLLC lead notification</p>
          </div>`;

        if (!RESEND_API_KEY) {
          console.warn("[contact] RESEND_API_KEY not set; logging lead only", {
            to: TO,
            from: data.email,
            name: data.name,
          });
          return Response.json({ ok: true, delivered: false });
        }

        const confirmationHtml = `
          <div style="font-family:Inter,Arial,sans-serif;max-width:560px;margin:auto;color:#0f172a">
            <h2 style="color:#072A6C;margin:0 0 12px">Thank you, ${escapeHtml(data.name)}!</h2>
            <p style="color:#475569;margin:0 0 16px">We received your message and our team will get back to you shortly (usually within one business day).</p>
            <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:16px;margin:16px 0">
              <p style="margin:0 0 8px;color:#64748b;font-size:12px;text-transform:uppercase;letter-spacing:.05em">Your message</p>
              <p style="white-space:pre-wrap;margin:0;font-size:14px">${escapeHtml(data.message)}</p>
            </div>
            <p style="color:#475569;margin:16px 0 0;font-size:14px">If it's urgent, reach us at <a href="mailto:info@amconsultingllc.net" style="color:#072A6C">info@amconsultingllc.net</a>.</p>
            <hr style="border:none;border-top:1px solid #e2e8f0;margin:24px 0" />
            <p style="font-size:12px;color:#94a3b8">AMCONSULTINGLLC · amconsultingllc.net</p>
          </div>`;

        try {
          const [notifyRes, confirmRes] = await Promise.all([
            fetch("https://api.resend.com/emails", {
              method: "POST",
              headers: {
                Authorization: `Bearer ${RESEND_API_KEY}`,
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                from: FROM,
                to: [TO],
                reply_to: data.email,
                subject,
                html,
              }),
            }),
            fetch("https://api.resend.com/emails", {
              method: "POST",
              headers: {
                Authorization: `Bearer ${RESEND_API_KEY}`,
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                from: FROM,
                to: [data.email],
                reply_to: TO,
                subject: "We received your message — AMCONSULTINGLLC",
                html: confirmationHtml,
              }),
            }),
          ]);

          if (!notifyRes.ok) {
            const errText = await notifyRes.text();
            console.error("[contact] Resend notify error", notifyRes.status, errText);
            return Response.json(
              { ok: false, error: "Email delivery failed" },
              { status: 502 },
            );
          }

          if (!confirmRes.ok) {
            const errText = await confirmRes.text();
            console.error("[contact] Resend confirmation error", confirmRes.status, errText);
          }

          return Response.json({ ok: true, delivered: true, confirmationSent: confirmRes.ok });
        } catch (err) {
          console.error("[contact] send failed", err);
          return Response.json(
            { ok: false, error: "Unexpected server error" },
            { status: 500 },
          );
        }

      },
    },
  },
});
