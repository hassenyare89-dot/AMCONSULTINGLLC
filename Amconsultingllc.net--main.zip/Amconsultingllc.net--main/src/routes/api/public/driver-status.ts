import { createFileRoute } from "@tanstack/react-router";

// Per-instance rate limiting (resets on cold start).
// Two layers: per-IP (broad abuse) and per-id (targeted guessing).
const IP_HITS = new Map<string, { count: number; reset: number }>();
const ID_HITS = new Map<string, { count: number; fails: number; reset: number }>();
const IP_WINDOW_MS = 60_000;
const IP_MAX = 20;
const ID_WINDOW_MS = 10 * 60_000;
const ID_MAX_FAILS = 5;
// Cap map sizes to avoid unbounded memory growth
const MAX_ENTRIES = 5000;

function sweep(map: Map<string, { reset: number }>) {
  if (map.size < MAX_ENTRIES) return;
  const now = Date.now();
  for (const [k, v] of map) if (v.reset < now) map.delete(k);
  if (map.size >= MAX_ENTRIES) {
    // Hard cap: drop oldest-ish (first inserted)
    const excess = map.size - Math.floor(MAX_ENTRIES * 0.8);
    let i = 0;
    for (const k of map.keys()) {
      if (i++ >= excess) break;
      map.delete(k);
    }
  }
}

function checkIp(ip: string): boolean {
  const now = Date.now();
  sweep(IP_HITS);
  const entry = IP_HITS.get(ip);
  if (!entry || entry.reset < now) {
    IP_HITS.set(ip, { count: 1, reset: now + IP_WINDOW_MS });
    return true;
  }
  entry.count += 1;
  return entry.count <= IP_MAX;
}

function checkId(id: string): { allowed: boolean; blocked: boolean } {
  const now = Date.now();
  sweep(ID_HITS);
  const entry = ID_HITS.get(id);
  if (!entry || entry.reset < now) {
    ID_HITS.set(id, { count: 1, fails: 0, reset: now + ID_WINDOW_MS });
    return { allowed: true, blocked: false };
  }
  entry.count += 1;
  return { allowed: entry.fails < ID_MAX_FAILS, blocked: entry.fails >= ID_MAX_FAILS };
}

function recordIdFail(id: string) {
  const entry = ID_HITS.get(id);
  if (entry) entry.fails += 1;
}



export const Route = createFileRoute("/api/public/driver-status")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const ip =
          request.headers.get("cf-connecting-ip") ||
          request.headers.get("x-forwarded-for")?.split(",")[0].trim() ||
          "unknown";

        if (!checkIp(ip)) {
          return Response.json(
            { ok: false, error: "Too many requests. Please try again shortly." },
            { status: 429, headers: { "Retry-After": "60" } },
          );
        }

        const url = new URL(request.url);
        const id = url.searchParams.get("id");
        const email = url.searchParams.get("email")?.trim().toLowerCase();

        // Small constant delay to blunt rapid guessing / timing signals
        await new Promise((r) => setTimeout(r, 250));

        if (!id || !email) {
          return Response.json({ ok: false, error: "Missing id or email" }, { status: 400 });
        }
        // basic UUID shape check
        if (!/^[0-9a-f-]{36}$/i.test(id)) {
          return Response.json({ ok: false, error: "Invalid id" }, { status: 400 });
        }

        const idCheck = checkId(id);
        if (!idCheck.allowed) {
          return Response.json(
            { ok: false, error: "Too many attempts for this registration. Try again later." },
            { status: 429, headers: { "Retry-After": "600" } },
          );
        }

        try {
          const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
          const { data, error } = await supabaseAdmin
            .from("driver_registrations")
            .select(
              "id,status,owner_name,company_name,email,dot_number,mc_number,truck_type,truck_count,service_area,availability,created_at",
            )
            .eq("id", id)
            .maybeSingle();

          if (error || !data) {
            recordIdFail(id);
            return Response.json({ ok: false, error: "Not found" }, { status: 404 });
          }
          if (data.email.trim().toLowerCase() !== email) {
            recordIdFail(id);
            return Response.json({ ok: false, error: "Not found" }, { status: 404 });
          }

          return Response.json({ ok: true, registration: data });
        } catch (err) {
          console.error("[driver-status] error", err);
          return Response.json({ ok: false, error: "Server error" }, { status: 500 });
        }
      },
    },
  },
});
