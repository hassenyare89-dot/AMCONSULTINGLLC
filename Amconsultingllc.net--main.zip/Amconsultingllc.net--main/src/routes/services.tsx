import { createFileRoute } from "@tanstack/react-router";
import { Services } from "@/components/site/Services";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services | AMCONSULTINGLLC" },
      {
        name: "description",
        content:
          "Dump truck dispatching, load coordination, project scheduling, hauling logistics, and transportation consulting for contractors.",
      },
      { property: "og:title", content: "Services | AMCONSULTINGLLC" },
      {
        property: "og:description",
        content:
          "Full-service dispatching, hauling, and logistics support for construction teams.",
      },
    ],
    links: [{ rel: "canonical", href: "/services" }],
  }),
  component: () => (
    <div className="pt-16">
      <Services />
    </div>
  ),
});
