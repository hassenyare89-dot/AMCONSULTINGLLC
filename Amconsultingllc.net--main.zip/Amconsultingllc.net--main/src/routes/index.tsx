import { createFileRoute } from "@tanstack/react-router";
import { Hero } from "@/components/site/Hero";
import { Stats } from "@/components/site/Stats";
import { Services } from "@/components/site/Services";
import { WhoWeServe } from "@/components/site/WhoWeServe";
import { WhyUs } from "@/components/site/WhyUs";
import { Process } from "@/components/site/Process";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AM Consulting and Hauling | Dump Truck Dispatching Services" },
      {
        name: "description",
        content:
          "Professional dump truck dispatching, load coordination, and hauling logistics in Atlanta, GA. Keeping trucks moving and projects on schedule.",
      },
      { property: "og:title", content: "AM Consulting and Hauling | Dump Truck Dispatching Services" },
      {
        property: "og:description",
        content:
          "Dump truck dispatching and hauling logistics for contractors, fleet owners, and independent operators in Atlanta and surrounding areas.",
      },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      <Hero />
      <Stats />
      <Services />
      <WhoWeServe />
      <WhyUs />
      <Process />
    </>
  );
}

