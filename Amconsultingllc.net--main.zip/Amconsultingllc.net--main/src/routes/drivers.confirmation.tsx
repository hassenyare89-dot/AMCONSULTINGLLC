import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { CheckCircle2, Phone, Mail, FileCheck, Truck, MapPin, ClipboardList } from "lucide-react";
import { CONTACT } from "@/lib/contact";
import { Button } from "@/components/ui/button";
import { SectionHeader } from "@/components/site/Services";

type Summary = {
  ownerName: string;
  companyName?: string;
  email: string;
  phone: string;
  dotNumber: string;
  mcNumber?: string;
  truckType: string;
  truckCount: number;
  serviceArea: string;
  availability: string;
  id?: string | null;
  statusUrl?: string | null;
};

const STORAGE_KEY = "am_driver_registration";

const TRUCK_TYPE_LABELS: Record<string, string> = {
  tandem: "Tandem",
  "quad-axle": "Quad-axle",
  "side-dump": "Side dump",
  "super-dump": "Super dump",
  other: "Other",
};

const AVAILABILITY_LABELS: Record<string, string> = {
  "full-time": "Full-time",
  "part-time": "Part-time",
  "on-call": "On-call / as-needed",
};

export const Route = createFileRoute("/drivers/confirmation")({
  head: () => ({
    meta: [
      { title: "Registration Confirmed | AMCONSULTINGLLC" },
      {
        name: "description",
        content:
          "Your driver registration was received. See your submission summary and what to expect next from our dispatch team.",
      },
      { name: "robots", content: "noindex" },
      { property: "og:title", content: "Registration Confirmed | AMCONSULTINGLLC" },
    ],
    links: [{ rel: "canonical", href: "/drivers/confirmation" }],
  }),
  component: ConfirmationPage,
});

function ConfirmationPage() {
  const navigate = useNavigate();
  const [summary, setSummary] = useState<Summary | null>(null);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setHydrated(true);
    try {
      const raw = sessionStorage.getItem(STORAGE_KEY);
      if (raw) setSummary(JSON.parse(raw) as Summary);
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    if (hydrated && !summary) {
      // No summary in session — bounce back to the form after a tick.
      const t = setTimeout(() => navigate({ to: "/drivers" }), 50);
      return () => clearTimeout(t);
    }
  }, [hydrated, summary, navigate]);

  return (
    <div className="pt-16">
      <section className="relative py-20 sm:py-28 bg-background">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45 }}
            className="text-center"
          >
            <div className="mx-auto grid place-items-center w-16 h-16 rounded-full bg-brand-green/15 text-navy mb-5">
              <CheckCircle2 className="w-9 h-9" aria-hidden="true" />
            </div>
            <SectionHeader
              eyebrow="You're in"
              title="Registration received"
              subtitle="Thanks for registering your fleet. Our dispatch team will review your submission and reach out shortly with next steps."
            />
          </motion.div>

          {summary ? (
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="mt-10 rounded-3xl bg-card border border-border shadow-[var(--shadow-card)] p-6 sm:p-8"
            >
              <div className="flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                <ClipboardList className="w-4 h-4" aria-hidden="true" />
                Submission summary
              </div>

              <dl className="mt-5 grid sm:grid-cols-2 gap-x-8 gap-y-4">
                <SummaryRow label="Owner / Driver" value={summary.ownerName} />
                {summary.companyName ? (
                  <SummaryRow label="Company" value={summary.companyName} />
                ) : null}
                <SummaryRow label="Email" value={summary.email} />
                <SummaryRow label="Phone" value={summary.phone} />
                <SummaryRow label="DOT Number" value={summary.dotNumber} mono />
                <SummaryRow label="MC Number" value={summary.mcNumber || "—"} mono />
                <SummaryRow
                  label="Truck Type"
                  value={TRUCK_TYPE_LABELS[summary.truckType] ?? summary.truckType}
                  icon={<Truck className="w-4 h-4" />}
                />
                <SummaryRow label="Number of Trucks" value={String(summary.truckCount)} />
                <SummaryRow
                  label="Service Area"
                  value={summary.serviceArea}
                  icon={<MapPin className="w-4 h-4" />}
                />
                <SummaryRow
                  label="Availability"
                  value={AVAILABILITY_LABELS[summary.availability] ?? summary.availability}
                />
              </dl>
            </motion.div>
          ) : null}

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.15 }}
            className="mt-8 rounded-3xl bg-card border border-border shadow-[var(--shadow-card)] p-6 sm:p-8"
          >
            <h2 className="text-xl font-bold text-navy">What happens next</h2>
            <ol className="mt-5 space-y-4">
              <NextStep
                index={1}
                icon={<FileCheck className="w-5 h-5" />}
                title="Verification (within 1 business day)"
                body="We verify your DOT/MC, insurance, and authority. Have your COI and W-9 ready — we'll request them by email."
              />
              <NextStep
                index={2}
                icon={<Phone className="w-5 h-5" />}
                title="Dispatch call"
                body="A dispatcher calls to confirm equipment, service area, and rates so you can start receiving loads."
              />
              <NextStep
                index={3}
                icon={<Truck className="w-5 h-5" />}
                title="First load assigned"
                body="Once onboarded, you'll start getting consistent hauling work matched to your trucks and area."
              />
            </ol>

            <div className="mt-8 grid sm:grid-cols-2 gap-3">
              <Button
                asChild
                className="bg-brand-green hover:bg-brand-green/90 text-navy shadow-[var(--shadow-glow)]"
              >
                <a href={`tel:${CONTACT.phoneE164}`}>
                  <Phone className="w-4 h-4 mr-2" /> Call dispatch
                </a>
              </Button>
              <Button asChild variant="outline">
                <a href="mailto:info@amconsultingllc.net">
                  <Mail className="w-4 h-4 mr-2" /> Email us
                </a>
              </Button>
            </div>

            {summary?.id ? (
              <div className="mt-6 rounded-2xl border border-border bg-muted/30 p-5 text-center">
                <div className="text-sm text-muted-foreground mb-3">
                  We've emailed you a link to track your application. You can also bookmark it here:
                </div>
                <Button asChild variant="secondary">
                  <Link
                    to="/drivers/status"
                    search={{ id: summary.id, email: summary.email }}
                  >
                    <ClipboardList className="w-4 h-4 mr-2" /> Check submission status
                  </Link>
                </Button>
              </div>
            ) : null}


            <div className="mt-6 text-center text-sm text-muted-foreground">
              <Link
                to="/"
                className="underline decoration-brand-green decoration-2 underline-offset-4 hover:text-navy focus-visible:focus-brand rounded"
              >
                Return to home
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}

function SummaryRow({
  label,
  value,
  mono,
  icon,
}: {
  label: string;
  value: string;
  mono?: boolean;
  icon?: React.ReactNode;
}) {
  return (
    <div>
      <dt className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        {label}
      </dt>
      <dd
        className={`mt-1 flex items-center gap-2 text-base font-semibold text-navy ${
          mono ? "font-mono tracking-wide" : ""
        }`}
      >
        {icon ? (
          <span className="text-brand-green" aria-hidden="true">
            {icon}
          </span>
        ) : null}
        <span className="break-words">{value}</span>
      </dd>
    </div>
  );
}

function NextStep({
  index,
  icon,
  title,
  body,
}: {
  index: number;
  icon: React.ReactNode;
  title: string;
  body: string;
}) {
  return (
    <li className="flex items-start gap-4">
      <span
        className="grid place-items-center w-10 h-10 rounded-xl text-white shrink-0 relative"
        style={{ background: "var(--gradient-accent)" }}
        aria-hidden="true"
      >
        {icon}
        <span className="absolute -top-1 -right-1 grid place-items-center w-5 h-5 rounded-full bg-navy text-white text-[10px] font-bold">
          {index}
        </span>
      </span>
      <div>
        <div className="font-semibold text-navy">{title}</div>
        <div className="text-sm text-muted-foreground mt-0.5">{body}</div>
      </div>
    </li>
  );
}
