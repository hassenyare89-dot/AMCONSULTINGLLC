import { createFileRoute } from "@tanstack/react-router";
import { Contact } from "@/components/site/Contact";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact | AMCONSULTINGLLC" },
      {
        name: "description",
        content:
          "Request dispatch services or talk with our hauling logistics team. We respond fast and keep your project moving.",
      },
      { property: "og:title", content: "Contact | AMCONSULTINGLLC" },
      {
        property: "og:description",
        content: "Get in touch with AMCONSULTINGLLC for dispatching and hauling support.",
      },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: () => (
    <div className="pt-16">
      <Contact />
    </div>
  ),
});
