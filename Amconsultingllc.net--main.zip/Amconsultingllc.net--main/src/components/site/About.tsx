import { motion } from "framer-motion";
import { CheckCircle2 } from "lucide-react";
import aboutImg from "@/assets/about-trucks.jpg.asset.json";
import { SectionHeader } from "./Services";

const bullets = [
  "Dispatching & logistics support built for the hauling industry",
  "Helping truck owners increase utilization and reduce downtime",
  "Reliable hauling solutions for contractors and project owners",
  "Transparent communication from first call to final load",
];

export function About() {
  return (
    <section id="about" className="relative py-24 sm:py-32 bg-secondary/50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="relative rounded-3xl overflow-hidden shadow-[var(--shadow-elevated)]"
        >
          <img
            src={aboutImg.url}
            alt="Dump trucks staged at a construction site"
            className="w-full h-full object-cover aspect-[4/3]"
            loading="lazy"
            width={1600}
            height={1100}
          />
          <div
            className="absolute bottom-6 left-6 right-6 glass-dark rounded-xl p-4 text-white"
          >
            <div className="flex items-center justify-between text-xs uppercase tracking-wider text-brand-green-soft font-semibold">
              <span>Built for the field</span>
              <span>Since day one</span>
            </div>
            <p className="mt-2 text-sm">
              We treat your project like our own — every load, every shift, every site.
            </p>
          </div>
        </motion.div>

        <div>
          <SectionHeader
            eyebrow="About us"
            title="AM Consulting and Hauling"
            subtitle="We specialize in dispatching and logistics support for the hauling industry. Our goal is to help truck owners increase utilization while providing contractors with reliable hauling solutions for their projects."
          />

          <ul className="mt-8 space-y-3">
            {bullets.map((b, i) => (
              <motion.li
                key={b}
                initial={{ opacity: 0, x: -12 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
                className="flex items-start gap-3 text-foreground"
              >
                <CheckCircle2 className="w-5 h-5 text-brand-green mt-0.5 shrink-0" />
                <span className="text-sm sm:text-base">{b}</span>
              </motion.li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
