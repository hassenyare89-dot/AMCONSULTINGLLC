import { Facebook, Linkedin, Instagram, Twitter, Phone, Mail, MapPin } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { CONTACT } from "@/lib/contact";
import { Logo } from "./Logo";

const nav = [
  { label: "Home", to: "/" },
  { label: "Services", to: "/services" },
  { label: "About", to: "/about" },
  { label: "Process", to: "/process" },
  { label: "Contact", to: "/contact" },
] as const;

const services = [
  "Dump Truck Dispatching",
  "Load Coordination",
  "Project Scheduling",
  "Hauling Logistics",
  "Transportation Consulting",
  "Contractor Support",
];

export function Footer() {
  return (
    <footer
      className="relative text-white pt-20 pb-8"
      style={{ background: "var(--gradient-hero)" }}
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-4">
          <div className="lg:col-span-2">
            <div className="[&_a]:!text-white">
              <Logo light />
            </div>
            <p className="mt-4 text-sm text-white/70 max-w-sm">
              AMCONSULTINGLLC provides dispatching, hauling consulting, and logistics coordination
              that keep construction projects on schedule.
            </p>
            <div className="mt-5 flex gap-3">
              {[Facebook, Linkedin, Instagram, Twitter].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  aria-label="Social link"
                  className="grid place-items-center w-9 h-9 rounded-lg glass-dark text-white hover:bg-brand-green/30 hover:text-brand-green active:bg-brand-green/40 focus-visible:focus-brand transition-colors aria-disabled:opacity-50 aria-disabled:pointer-events-none"
                >
                  <Icon className="w-4 h-4" aria-hidden="true" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-brand-green-soft">
              Quick links
            </h4>
            <ul className="mt-4 space-y-2">
              {nav.map((n) => (
                <li key={n.to}>
                  <Link to={n.to} className="inline-block rounded text-sm text-white/80 hover:text-brand-green hover:underline hover:decoration-brand-green hover:underline-offset-4 active:text-brand-green/80 focus-visible:focus-brand transition-colors aria-disabled:opacity-50 aria-disabled:pointer-events-none">
                    {n.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-brand-green-soft">
              Services
            </h4>
            <ul className="mt-4 space-y-2">
              {services.map((s) => (
                <li key={s}>
                  <Link to="/services" className="inline-block rounded text-sm text-white/80 hover:text-brand-green hover:underline hover:decoration-brand-green hover:underline-offset-4 active:text-brand-green/80 focus-visible:focus-brand transition-colors aria-disabled:opacity-50 aria-disabled:pointer-events-none">
                    {s}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-brand-green-soft">
              Contact
            </h4>
            <ul className="mt-4 space-y-3">
              <li>
                <a
                  href={`tel:${CONTACT.phoneE164}`}
                  className="inline-flex items-center gap-2 rounded text-sm text-white/80 hover:text-brand-green hover:underline hover:decoration-brand-green hover:underline-offset-4 active:text-brand-green/80 focus-visible:focus-brand transition-colors"
                >
                  <Phone className="w-4 h-4" aria-hidden="true" /> {CONTACT.phone}
                </a>
              </li>
              <li>
                <a
                  href={`mailto:${CONTACT.email}`}
                  className="inline-flex items-center gap-2 rounded text-sm text-white/80 hover:text-brand-green hover:underline hover:decoration-brand-green hover:underline-offset-4 active:text-brand-green/80 focus-visible:focus-brand transition-colors"
                >
                  <Mail className="w-4 h-4" aria-hidden="true" /> {CONTACT.email}
                </a>
              </li>
              <li>
                <a
                  href={CONTACT.mapSearchUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-start gap-2 rounded text-sm text-white/80 hover:text-brand-green hover:underline hover:decoration-brand-green hover:underline-offset-4 active:text-brand-green/80 focus-visible:focus-brand transition-colors"
                >
                  <MapPin className="w-4 h-4 mt-0.5 shrink-0" aria-hidden="true" />
                  <span>{CONTACT.address.full}</span>
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-white/60">
          <p>© {new Date().getFullYear()} AMCONSULTINGLLC. All rights reserved.</p>
          <p>Keeping trucks moving. Keeping projects on schedule.</p>
        </div>
      </div>
    </footer>
  );
}
