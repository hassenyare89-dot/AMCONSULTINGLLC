import { Link } from "@tanstack/react-router";
import logo from "@/assets/am-logo-full.png.asset.json";

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link
      to="/"
      className="flex items-center group rounded-md"
      aria-label="AM Consulting & Hauling home"
    >
      <span
        className={`inline-flex items-center rounded-md transition-colors ${
          light ? "bg-white/95 px-2 py-1 shadow-[0_4px_18px_-6px_rgba(0,0,0,0.45)]" : ""
        }`}
      >
        <img
          src={logo.url}
          alt=""
          aria-hidden="true"
          className="h-10 w-auto transition-transform group-hover:scale-[1.03]"
        />
      </span>
    </Link>
  );
}
