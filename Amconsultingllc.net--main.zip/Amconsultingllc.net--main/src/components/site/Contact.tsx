import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Phone,
  Mail,
  MapPin,
  Send,
  ArrowRight,
  ExternalLink,
  Clock,
  CheckCircle2,
  Copy,
  Check,
  CalendarClock,
  ShieldCheck,
  PhoneCall,
  Loader2,
} from "lucide-react";
import { z } from "zod";
import { CONTACT } from "@/lib/contact";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";



const MONO = { fontFamily: "'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, monospace" } as const;

const SERVICES = [
  "Full Truckload (FTL) Hauling",
  "Dedicated Dispatching Services",
  "Logistics Coordination",
  "Fleet & Owner-Operator Support",
  "Consulting / Other",
] as const;

const schema = z.object({
  name: z.string().trim().min(1, "Contact name is required").max(100),
  email: z.string().trim().email("Please enter a valid email").max(255),
  phone: z.string().trim().max(30).optional().or(z.literal("")),
  company: z.string().trim().max(120).optional().or(z.literal("")),
  address: z.string().trim().max(300).optional().or(z.literal("")),
  service: z.string().trim().max(120).optional().or(z.literal("")),
  message: z.string().trim().min(10, "Share a few project details (10+ characters)").max(1000),
});

type Submission = {
  ref: string;
  name: string;
  email: string;
  service: string;
  submittedAt: Date;
};

function makeRef(d: Date) {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  const rand = Math.random().toString(36).slice(2, 7).toUpperCase();
  return `AMC-${yyyy}${mm}${dd}-${rand}`;
}

export function Contact() {
  const [submitting, setSubmitting] = useState(false);
  const [service, setService] = useState<string>(SERVICES[0]);
  const [charCount, setCharCount] = useState(0);
  const [success, setSuccess] = useState<Submission | null>(null);
  const mountedAt = useRef<number>(Date.now());

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (submitting) return;
    const form = e.currentTarget;
    const fd = new FormData(form);
    const data = Object.fromEntries(fd) as Record<string, string>;
    data.service = service;
    const parsed = schema.safeParse(data);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Please check your inputs");
      return;
    }

    const contextLines: string[] = [];
    if (parsed.data.company) contextLines.push(`Company: ${parsed.data.company}`);
    if (parsed.data.address) contextLines.push(`Address: ${parsed.data.address}`);
    if (parsed.data.service) contextLines.push(`Service of interest: ${parsed.data.service}`);
    const composedMessage =
      contextLines.length > 0
        ? `${contextLines.join("\n")}\n\n${parsed.data.message}`
        : parsed.data.message;

    setSubmitting(true);
    try {
      const res = await fetch("/api/public/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: parsed.data.name,
          email: parsed.data.email,
          phone: parsed.data.phone ?? "",
          message: composedMessage,
          website: data.website ?? "",
          ts: mountedAt.current,
        }),
      });
      const json = (await res.json().catch(() => ({}))) as {
        ok?: boolean;
        error?: string;
      };
      if (!res.ok || !json.ok) {
        toast.error(json.error || "Something went wrong. Please try again.");
        return;
      }
      const now = new Date();
      form.reset();
      setService(SERVICES[0]);
      setCharCount(0);
      mountedAt.current = Date.now();
      setSuccess({
        ref: makeRef(now),
        name: parsed.data.name,
        email: parsed.data.email,
        service: parsed.data.service || SERVICES[0],
        submittedAt: now,
      });
      // Scroll section into view so the user sees the confirmation
      requestAnimationFrame(() => {
        document.getElementById("contact")?.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    } catch {
      toast.error("Network error. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section id="contact" className="relative py-24 sm:py-32 bg-slate-50">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        {/* Eyebrow header */}
        <div className="mb-10 text-center">

          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-emerald-500/30 bg-emerald-500/10">
            <span
              style={MONO}
              className="text-[10px] font-bold tracking-[0.2em] text-emerald-600 uppercase"
            >
              Operational Contact
            </span>
          </div>
          <h2 className="mt-5 text-4xl sm:text-5xl font-bold tracking-tight text-slate-900">
            Route Inquiry
          </h2>
          <p className="mt-3 text-slate-500 max-w-xl mx-auto">
            Complete the manifest below to initiate logistical coordination. Our dispatch team responds within one business day.
          </p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="bg-white shadow-2xl rounded-sm border border-slate-200 flex flex-col md:flex-row overflow-hidden"
        >
          {/* Sidebar: Operational HQ */}
          <aside className="md:w-1/3 bg-[#0f172a] p-8 sm:p-10 text-white flex flex-col justify-between relative overflow-hidden">
            {/* Decorative technical element */}
            <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
              <svg width="140" height="140" viewBox="0 0 100 100" fill="none" stroke="currentColor">
                <circle cx="50" cy="50" r="40" strokeDasharray="4 4" />
                <path d="M50 10V90M10 50H90" />
              </svg>
            </div>

            <div className="relative z-10">
              <div className="inline-block px-3 py-1 bg-emerald-500/10 border border-emerald-500/30 rounded-full mb-6">
                <span
                  style={MONO}
                  className="text-[10px] font-bold tracking-[0.2em] text-emerald-400 uppercase"
                >
                  Operational HQ
                </span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-bold leading-tight mb-8">
                Connect with <br />
                <span className="text-emerald-400">AMCONSULTINGLLC</span>
              </h3>

              <div className="space-y-7">
                <div>
                  <p
                    style={MONO}
                    className="text-[11px] uppercase tracking-widest text-slate-400 mb-1.5"
                  >
                    Dispatch Line
                  </p>
                  <a
                    href={`tel:${CONTACT.phoneE164}`}
                    className="group inline-flex items-center gap-2 text-lg font-semibold hover:text-emerald-400 transition-colors"
                  >
                    <Phone className="w-4 h-4 text-emerald-400" />
                    {CONTACT.phone}
                  </a>
                </div>
                <div>
                  <p
                    style={MONO}
                    className="text-[11px] uppercase tracking-widest text-slate-400 mb-1.5"
                  >
                    Logistics Support
                  </p>
                  <a
                    href={`mailto:${CONTACT.email}`}
                    className="group inline-flex items-center gap-2 text-lg font-semibold hover:text-emerald-400 transition-colors break-all"
                  >
                    <Mail className="w-4 h-4 text-emerald-400 shrink-0" />
                    {CONTACT.email}
                  </a>
                </div>
                <div>
                  <p
                    style={MONO}
                    className="text-[11px] uppercase tracking-widest text-slate-400 mb-1.5"
                  >
                    Field Office
                  </p>
                  <a
                    href={CONTACT.mapSearchUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group inline-flex items-start gap-2 text-base font-semibold leading-snug hover:text-emerald-400 transition-colors"
                  >
                    <MapPin className="w-4 h-4 text-emerald-400 mt-1 shrink-0" />
                    <span>{CONTACT.address.full}</span>
                  </a>
                </div>
                <div>
                  <p
                    style={MONO}
                    className="text-[11px] uppercase tracking-widest text-slate-400 mb-1.5"
                  >
                    Service Window
                  </p>
                  <div className="inline-flex items-center gap-2 text-lg font-semibold">
                    <Clock className="w-4 h-4 text-emerald-400" />
                    Mon–Fri · 7am – 6pm ET
                  </div>
                  <p className="mt-1 text-xs text-slate-400">24/7 dispatch for active loads</p>
                </div>
              </div>
            </div>

            <div className="mt-10 pt-6 border-t border-slate-800 relative z-10">
              <div className="flex items-center gap-3">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75 animate-ping" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
                </span>
                <span
                  style={MONO}
                  className="text-[11px] text-slate-400 uppercase tracking-widest font-semibold"
                >
                  Systems Active
                </span>
              </div>
            </div>
          </aside>

          {/* Form: Route Inquiry */}
          <div className="md:w-2/3 p-8 sm:p-10 bg-white relative">
            {/* Subtle dot-grid backdrop */}
            <div
              aria-hidden="true"
              className="absolute inset-0 opacity-[0.04] pointer-events-none"
              style={{
                backgroundImage: "radial-gradient(#0f172a 1px, transparent 1px)",
                backgroundSize: "24px 24px",
              }}
            />

            <div className="relative z-10">
              <AnimatePresence mode="wait" initial={false}>
                {success ? (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    transition={{ duration: 0.35 }}
                  >
                    <SuccessPanel data={success} onReset={() => setSuccess(null)} />
                  </motion.div>
                ) : (
                  <motion.div
                    key="form"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.25 }}
                  >
                    <header className="mb-8 pb-5 border-b border-slate-100 flex items-start justify-between gap-4">
                      <div>
                        <div
                          style={MONO}
                          className="text-[10px] font-bold tracking-[0.2em] text-emerald-600 uppercase mb-2"
                        >
                          Form · 01 / Inbound
                        </div>
                        <h3 className="text-2xl font-bold text-slate-900">Request a quote</h3>
                        <p className="text-slate-500 mt-1 text-sm">
                          Share your route details and we'll coordinate the rest.
                        </p>
                      </div>
                      <div
                        style={MONO}
                        className="hidden sm:block text-[10px] text-slate-400 uppercase tracking-widest text-right"
                      >
                        <div>Priority</div>
                        <div className="text-emerald-600 font-bold">Standard</div>
                      </div>
                    </header>

                    <form
                      onSubmit={onSubmit}
                      aria-busy={submitting}
                      className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-5"
                    >
                      {/* Honeypot */}
                      <div aria-hidden="true" className="absolute -left-[9999px] w-0 h-0 overflow-hidden">
                        <label htmlFor="website">Website</label>
                        <input id="website" name="website" type="text" tabIndex={-1} autoComplete="off" />
                      </div>

                      <Field label="Contact Name" required htmlFor="name">
                        <input
                          id="name"
                          name="name"
                          type="text"
                          autoComplete="name"
                          required
                          maxLength={100}
                          placeholder="Jane Doe"
                          disabled={submitting}
                          className={inputClass}
                        />
                      </Field>

                      <Field label="Organization" htmlFor="company">
                        <input
                          id="company"
                          name="company"
                          type="text"
                          autoComplete="organization"
                          maxLength={120}
                          placeholder="Global Freight Inc."
                          disabled={submitting}
                          className={inputClass}
                        />
                      </Field>

                      <Field label="Network Email" required htmlFor="email">
                        <input
                          id="email"
                          name="email"
                          type="email"
                          autoComplete="email"
                          required
                          maxLength={255}
                          placeholder="j.doe@logistics.com"
                          disabled={submitting}
                          className={inputClass}
                        />
                      </Field>

                      <Field label="Direct Line" htmlFor="phone">
                        <input
                          id="phone"
                          name="phone"
                          type="tel"
                          autoComplete="tel"
                          maxLength={30}
                          placeholder={CONTACT.phone}
                          disabled={submitting}
                          className={inputClass}
                        />
                      </Field>

                      <Field label="Pickup / Delivery Address" htmlFor="address" span2>
                        <AddressAutocomplete disabled={submitting} />
                      </Field>

                      <Field label="Logistics Service" htmlFor="service" span2>
                        <div className="relative">
                          <select
                            id="service"
                            value={service}
                            onChange={(e) => setService(e.target.value)}
                            disabled={submitting}
                            className={`${inputClass} appearance-none pr-10 cursor-pointer disabled:cursor-not-allowed`}
                          >
                            {SERVICES.map((s) => (
                              <option key={s} value={s}>
                                {s}
                              </option>
                            ))}
                          </select>
                          <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                            <svg
                              className="w-4 h-4 text-slate-400"
                              fill="none"
                              stroke="currentColor"
                              viewBox="0 0 24 24"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth="2"
                                d="M19 9l-7 7-7-7"
                              />
                            </svg>
                          </div>
                        </div>
                      </Field>

                      <Field label="Project Intel" required htmlFor="message" span2>
                        <textarea
                          id="message"
                          name="message"
                          rows={5}
                          required
                          maxLength={1000}
                          placeholder="Volume, materials, pickup/delivery location, timeline, and any special requirements..."
                          onChange={(e) => setCharCount(e.target.value.length)}
                          disabled={submitting}
                          className={`${inputClass} resize-none`}
                        />
                        <div className="mt-1.5 flex justify-between text-[11px]" style={MONO}>
                          <span className="text-slate-400 uppercase tracking-wider">
                            Include volume · timeline · locations
                          </span>
                          <span
                            className={`uppercase tracking-wider font-semibold ${
                              charCount > 900 ? "text-amber-600" : "text-slate-400"
                            }`}
                          >
                            {charCount} / 1000
                          </span>
                        </div>
                      </Field>

                      {/* CTA */}
                      <div className="md:col-span-2 pt-3">
                        <Button
                          type="submit"
                          disabled={submitting}
                          className="w-full bg-emerald-500 hover:bg-emerald-600 disabled:bg-emerald-500/70 disabled:cursor-not-allowed text-white py-6 px-8 rounded-none flex items-center justify-center gap-3 group shadow-[0_4px_20px_rgba(16,185,129,0.3)] hover:shadow-[0_8px_30px_rgba(16,185,129,0.4)] disabled:shadow-none transition-all"
                        >
                          {submitting ? (
                            <Loader2 className="w-5 h-5 animate-spin" aria-hidden="true" />
                          ) : (
                            <Send className="w-4 h-4" aria-hidden="true" />
                          )}
                          <span className="tracking-[0.2em] uppercase text-sm font-bold">
                            {submitting ? "Transmitting…" : "Initialize Partnership"}
                          </span>
                          {!submitting && (
                            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" aria-hidden="true" />
                          )}
                        </Button>
                        <p
                          style={MONO}
                          className="mt-3 text-[10px] text-slate-400 uppercase tracking-widest text-center"
                        >
                          Encrypted transmission · Details stay private
                        </p>
                      </div>
                    </form>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

          </div>
        </motion.div>

        {/* Map — full width beneath */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="mt-8 rounded-sm overflow-hidden border border-slate-200 shadow-2xl aspect-[16/6] relative bg-white"
        >
          <iframe
            title="Office location map — AM Consulting & Hauling"
            src={CONTACT.mapEmbedUrl}
            className="w-full h-full"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
          <a
            href={CONTACT.mapSearchUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="absolute bottom-4 right-4 inline-flex items-center gap-1.5 rounded-full bg-white/95 px-3.5 py-2 text-xs font-semibold text-slate-900 shadow-lg hover:bg-white"
          >
            View larger map <ExternalLink className="w-3 h-3" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

const inputClass =
  "w-full bg-slate-50 border-b-2 border-slate-200 px-4 py-3 focus:border-emerald-500 focus:bg-white outline-none transition-all placeholder:text-slate-300 text-slate-900 text-sm disabled:opacity-60 disabled:cursor-not-allowed";

function Field({
  label,
  htmlFor,
  required,
  span2,
  children,
}: {
  label: string;
  htmlFor: string;
  required?: boolean;
  span2?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className={`space-y-1.5 ${span2 ? "md:col-span-2" : ""}`}>
      <label
        htmlFor={htmlFor}
        style={MONO}
        className="block text-[11px] font-bold text-slate-500 uppercase tracking-widest"
      >
        {label} {required && <span className="text-emerald-600">*</span>}
      </label>
      {children}
    </div>
  );
}

function SuccessPanel({
  data,
  onReset,
}: {
  data: Submission;
  onReset: () => void;
}) {
  const [copied, setCopied] = useState(false);

  const copyRef = async () => {
    try {
      await navigator.clipboard.writeText(data.ref);
      setCopied(true);
      toast.success("Reference number copied");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Couldn't copy. Please copy manually.");
    }
  };

  const submittedLabel = data.submittedAt.toLocaleString(undefined, {
    dateStyle: "medium",
    timeStyle: "short",
  });

  return (
    <div>
      {/* Confirmation header */}
      <header className="mb-8 pb-5 border-b border-slate-100 flex items-start justify-between gap-4">
        <div className="flex items-start gap-4">
          <motion.div
            initial={{ scale: 0.6, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 260, damping: 18 }}
            className="grid place-items-center w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/40 shrink-0"
          >
            <CheckCircle2 className="w-6 h-6 text-emerald-600" />
          </motion.div>
          <div>
            <div
              style={MONO}
              className="text-[10px] font-bold tracking-[0.2em] text-emerald-600 uppercase mb-2"
            >
              Transmission · Confirmed
            </div>
            <h3 className="text-2xl font-bold text-slate-900">Request received</h3>
            <p className="text-slate-500 mt-1 text-sm">
              Thank you, <span className="font-semibold text-slate-700">{data.name.split(" ")[0]}</span>. Your inquiry is logged and routed to dispatch.
            </p>
          </div>
        </div>
        <div
          style={MONO}
          className="hidden sm:block text-[10px] text-slate-400 uppercase tracking-widest text-right"
        >
          <div>Status</div>
          <div className="text-emerald-600 font-bold">Queued</div>
        </div>
      </header>

      {/* Reference number ticket */}
      <div className="mb-6 border border-slate-200 bg-slate-50 relative overflow-hidden">
        {/* corner ticks */}
        <span className="absolute top-0 left-0 w-2 h-2 border-t-2 border-l-2 border-emerald-500" />
        <span className="absolute top-0 right-0 w-2 h-2 border-t-2 border-r-2 border-emerald-500" />
        <span className="absolute bottom-0 left-0 w-2 h-2 border-b-2 border-l-2 border-emerald-500" />
        <span className="absolute bottom-0 right-0 w-2 h-2 border-b-2 border-r-2 border-emerald-500" />

        <div className="px-5 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <div
              style={MONO}
              className="text-[10px] font-bold tracking-[0.2em] text-slate-500 uppercase"
            >
              Reference Number
            </div>
            <div
              style={MONO}
              className="mt-1 text-xl sm:text-2xl font-bold text-slate-900 tracking-wide select-all"
            >
              {data.ref}
            </div>
          </div>
          <button
            type="button"
            onClick={copyRef}
            className="inline-flex items-center gap-2 px-3 py-2 border border-slate-300 bg-white text-xs font-bold uppercase tracking-widest text-slate-700 hover:bg-slate-900 hover:text-white hover:border-slate-900 transition-colors"
            style={MONO}
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5" /> Copied
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" /> Copy
              </>
            )}
          </button>
        </div>
        <div className="border-t border-dashed border-slate-300 px-5 py-3 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <SummaryCell label="Submitted" value={submittedLabel} />
          <SummaryCell label="Reply to" value={data.email} truncate />
          <SummaryCell label="Service" value={data.service} truncate />
        </div>
      </div>

      {/* Next steps */}
      <div className="mb-6">
        <div
          style={MONO}
          className="text-[10px] font-bold tracking-[0.2em] text-slate-500 uppercase mb-3"
        >
          Next Steps
        </div>
        <ol className="space-y-3">
          <Step
            index="01"
            icon={<Mail className="w-4 h-4" />}
            title="Check your inbox"
            body={`A confirmation is on its way to ${data.email}. If it doesn't appear within a few minutes, check your spam folder.`}
          />
          <Step
            index="02"
            icon={<CalendarClock className="w-4 h-4" />}
            title="Dispatch review · within 1 business day"
            body="A dispatcher reviews your request and matches it to available capacity, then contacts you with next steps and pricing."
          />
          <Step
            index="03"
            icon={<ShieldCheck className="w-4 h-4" />}
            title="Coordination & scheduling"
            body="We'll confirm logistics, insurance, and timelines. Your reference number stays with your file throughout."
          />
        </ol>
      </div>

      {/* Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-slate-100">
        <Button
          asChild
          className="w-full bg-slate-900 hover:bg-slate-800 text-white py-5 rounded-none flex items-center justify-center gap-2"
        >
          <a href={`tel:${CONTACT.phoneE164}`}>
            <PhoneCall className="w-4 h-4" />
            <span
              style={MONO}
              className="tracking-[0.2em] uppercase text-xs font-bold"
            >
              Call Dispatch Now
            </span>
          </a>
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={onReset}
          className="w-full border-slate-300 text-slate-700 hover:bg-slate-50 py-5 rounded-none flex items-center justify-center gap-2"
        >
          <span
            style={MONO}
            className="tracking-[0.2em] uppercase text-xs font-bold"
          >
            Submit Another Request
          </span>
        </Button>
      </div>
    </div>
  );
}

function SummaryCell({
  label,
  value,
  truncate,
}: {
  label: string;
  value: string;
  truncate?: boolean;
}) {
  return (
    <div>
      <div
        style={MONO}
        className="text-[10px] font-bold uppercase tracking-widest text-slate-400"
      >
        {label}
      </div>
      <div className={`mt-0.5 text-sm font-semibold text-slate-900 ${truncate ? "truncate" : ""}`}>
        {value}
      </div>
    </div>
  );
}

function Step({
  index,
  icon,
  title,
  body,
}: {
  index: string;
  icon: React.ReactNode;
  title: string;
  body: string;
}) {
  return (
    <li className="flex gap-4 p-4 border border-slate-200 bg-white hover:border-emerald-500/40 transition-colors">
      <div className="flex flex-col items-center shrink-0">
        <span
          style={MONO}
          className="text-[10px] font-bold tracking-widest text-emerald-600"
        >
          {index}
        </span>
        <span className="mt-1 grid place-items-center w-8 h-8 rounded-full bg-slate-900 text-emerald-400">
          {icon}
        </span>
      </div>
      <div className="min-w-0">
        <div className="text-sm font-bold text-slate-900">{title}</div>
        <p className="mt-0.5 text-sm text-slate-500 leading-relaxed">{body}</p>
      </div>
    </li>
  );
}

type NominatimResult = {
  place_id: number;
  display_name: string;
  lat: string;
  lon: string;
};

function AddressAutocomplete({ disabled }: { disabled?: boolean }) {
  const [value, setValue] = useState("");
  const [results, setResults] = useState<NominatimResult[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [coords, setCoords] = useState<{ lat: string; lon: string } | null>(null);
  const [geoLoading, setGeoLoading] = useState(false);
  const skipNextFetch = useRef(false);
  const wrapperRef = useRef<HTMLDivElement>(null);

  // Debounced fetch from OpenStreetMap Nominatim (free, no API key)
  useEffect(() => {
    if (skipNextFetch.current) {
      skipNextFetch.current = false;
      return;
    }
    const q = value.trim();
    if (q.length < 3) {
      setResults([]);
      setOpen(false);
      return;
    }
    const controller = new AbortController();
    const t = setTimeout(async () => {
      setLoading(true);
      try {
        const url = `https://nominatim.openstreetmap.org/search?format=json&addressdetails=1&limit=5&q=${encodeURIComponent(q)}`;
        const res = await fetch(url, {
          signal: controller.signal,
          headers: { Accept: "application/json" },
        });
        if (!res.ok) throw new Error("bad status");
        const data = (await res.json()) as NominatimResult[];
        setResults(data);
        setOpen(data.length > 0);
      } catch {
        // silent
      } finally {
        setLoading(false);
      }
    }, 350);
    return () => {
      clearTimeout(t);
      controller.abort();
    };
  }, [value]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (!wrapperRef.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const select = (r: NominatimResult) => {
    skipNextFetch.current = true;
    setValue(r.display_name);
    setCoords({ lat: r.lat, lon: r.lon });
    setResults([]);
    setOpen(false);
  };

  const useMyLocation = () => {
    if (!("geolocation" in navigator)) {
      toast.error("Geolocation not supported by this browser");
      return;
    }
    setGeoLoading(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const { latitude, longitude } = pos.coords;
          const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`;
          const res = await fetch(url, { headers: { Accept: "application/json" } });
          const data = (await res.json()) as { display_name?: string };
          if (data.display_name) {
            skipNextFetch.current = true;
            setValue(data.display_name);
            setCoords({ lat: String(latitude), lon: String(longitude) });
          } else {
            toast.error("Couldn't resolve your address");
          }
        } catch {
          toast.error("Location lookup failed");
        } finally {
          setGeoLoading(false);
        }
      },
      () => {
        setGeoLoading(false);
        toast.error("Location permission denied");
      },
      { enableHighAccuracy: true, timeout: 10000 },
    );
  };

  return (
    <div ref={wrapperRef} className="relative">
      <div className="relative">
        <MapPin className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input
          id="address"
          name="address"
          type="text"
          autoComplete="street-address"
          value={value}
          onChange={(e) => {
            setValue(e.target.value);
            setCoords(null);
          }}
          onFocus={() => results.length > 0 && setOpen(true)}
          disabled={disabled}
          maxLength={300}
          placeholder="Start typing an address…"
          className={`${inputClass} pl-9 pr-28`}
        />
        <button
          type="button"
          onClick={useMyLocation}
          disabled={disabled || geoLoading}
          style={MONO}
          className="absolute right-2 top-1/2 -translate-y-1/2 inline-flex items-center gap-1 px-2.5 py-1.5 text-[10px] font-bold uppercase tracking-widest text-emerald-700 hover:text-emerald-800 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {geoLoading ? (
            <Loader2 className="w-3 h-3 animate-spin" />
          ) : (
            <MapPin className="w-3 h-3" />
          )}
          GPS
        </button>
      </div>

      {open && (
        <ul
          role="listbox"
          className="absolute z-20 mt-1 w-full max-h-64 overflow-auto bg-white border border-slate-200 shadow-xl rounded-sm"
        >
          {loading && (
            <li className="px-3 py-2 text-xs text-slate-400" style={MONO}>
              Searching…
            </li>
          )}
          {!loading && results.length === 0 && (
            <li className="px-3 py-2 text-xs text-slate-400" style={MONO}>
              No matches
            </li>
          )}
          {results.map((r) => (
            <li key={r.place_id}>
              <button
                type="button"
                onClick={() => select(r)}
                className="w-full text-left px-3 py-2 text-sm text-slate-700 hover:bg-emerald-50 hover:text-slate-900 flex items-start gap-2"
              >
                <MapPin className="w-3.5 h-3.5 mt-0.5 text-emerald-600 shrink-0" />
                <span className="line-clamp-2">{r.display_name}</span>
              </button>
            </li>
          ))}
        </ul>
      )}

      {coords && (
        <p
          style={MONO}
          className="mt-1.5 text-[10px] uppercase tracking-widest text-slate-400"
        >
          GPS · {Number(coords.lat).toFixed(5)}, {Number(coords.lon).toFixed(5)}
        </p>
      )}
    </div>
  );
}


