import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { Truck, ClipboardCheck } from "lucide-react";
import { useNavigate } from "@tanstack/react-router";
import { z } from "zod";
import { CONTACT } from "@/lib/contact";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { SectionHeader } from "./Services";

const DRIVER_STORAGE_KEY = "am_driver_registration";

const TRUCK_TYPES = [
  { value: "tandem", label: "Tandem" },
  { value: "quad-axle", label: "Quad-axle" },
  { value: "side-dump", label: "Side dump" },
  { value: "super-dump", label: "Super dump" },
  { value: "other", label: "Other" },
] as const;

const AVAILABILITY = [
  { value: "full-time", label: "Full-time" },
  { value: "part-time", label: "Part-time" },
  { value: "on-call", label: "On-call / as-needed" },
] as const;

const schema = z.object({
  ownerName: z.string().trim().min(1, "Owner name is required").max(100),
  companyName: z.string().trim().max(150).optional().or(z.literal("")),
  email: z.string().trim().email("Invalid email").max(255),
  phone: z.string().trim().min(7, "Phone is required").max(30),
  dotNumber: z
    .string()
    .trim()
    .min(4, "DOT number is required")
    .max(20)
    .regex(/^[0-9]+$/, "DOT number must be digits only"),
  mcNumber: z.string().trim().max(20).optional().or(z.literal("")),
  truckType: z.string().min(1, "Select a truck type"),
  truckCount: z.coerce.number().int().min(1, "At least 1 truck").max(500),
  serviceArea: z.string().trim().min(2, "Service area is required").max(200),
  availability: z.string().min(1, "Select availability"),
  notes: z.string().trim().max(1500).optional().or(z.literal("")),
});

export function DriverRegistration() {
  const [submitting, setSubmitting] = useState(false);
  const [truckType, setTruckType] = useState<string>("");
  const [availability, setAvailability] = useState<string>("");
  const mountedAt = useRef<number>(Date.now());
  const navigate = useNavigate();

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    const data = Object.fromEntries(fd) as Record<string, string>;
    data.truckType = truckType;
    data.availability = availability;

    const parsed = schema.safeParse(data);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Please check your inputs");
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/public/driver", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...parsed.data,
          website: data.website ?? "",
          ts: mountedAt.current,
        }),
      });
      const json = (await res.json().catch(() => ({}))) as {
        ok?: boolean;
        error?: string;
        id?: string | null;
        statusUrl?: string | null;
      };
      if (!res.ok || !json.ok) {
        toast.error(json.error || "Something went wrong. Please try again.");
        return;
      }
      form.reset();
      setTruckType("");
      setAvailability("");
      mountedAt.current = Date.now();
      try {
        sessionStorage.setItem(
          DRIVER_STORAGE_KEY,
          JSON.stringify({ ...parsed.data, id: json.id ?? null, statusUrl: json.statusUrl ?? null }),
        );
      } catch {
        // sessionStorage may be unavailable; confirmation page will fall back gracefully.
      }
      toast.success("You're registered! Our dispatch team will reach out shortly.");
      navigate({ to: "/drivers/confirmation" });
    } catch {
      toast.error("Network error. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="relative py-24 sm:py-32 bg-background">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <SectionHeader
          eyebrow="Drive with us"
          title="Owner-Operator Registration"
          subtitle="Run your trucks loaded. Register your fleet with our dispatch team and start receiving consistent hauling work in your service area."
        />

        <div className="mt-10 grid md:grid-cols-3 gap-4 mb-10">
          <Perk icon={<Truck className="w-5 h-5" />} title="Steady loads" body="Consistent dispatch in your preferred service area." />
          <Perk icon={<ClipboardCheck className="w-5 h-5" />} title="Quick onboarding" body="Submit your DOT and you can be working this week." />
          <Perk icon={<Truck className="w-5 h-5" />} title="All dump truck types" body="Tandems, quads, side dumps, super dumps — all welcome." />
        </div>

        <motion.form
          onSubmit={onSubmit}
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="rounded-3xl bg-card border border-border shadow-[var(--shadow-card)] p-6 sm:p-8 space-y-5"
        >
          {/* Honeypot */}
          <div aria-hidden="true" className="absolute -left-[9999px] w-0 h-0 overflow-hidden">
            <label htmlFor="website">Website</label>
            <input id="website" name="website" type="text" tabIndex={-1} autoComplete="off" />
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <Field id="ownerName" label="Owner / Driver name" required>
              <Input id="ownerName" name="ownerName" placeholder="John Smith" required maxLength={100} />
            </Field>
            <Field id="companyName" label="Company (optional)">
              <Input id="companyName" name="companyName" placeholder="Smith Hauling LLC" maxLength={150} />
            </Field>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <Field id="email" label="Email" required>
              <Input id="email" name="email" type="email" placeholder="you@company.com" required maxLength={255} />
            </Field>
            <Field id="phone" label="Phone" required>
              <Input id="phone" name="phone" type="tel" placeholder={CONTACT.phone} required maxLength={30} />
            </Field>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <Field id="dotNumber" label="DOT number" required>
              <Input
                id="dotNumber"
                name="dotNumber"
                inputMode="numeric"
                pattern="[0-9]*"
                placeholder="e.g. 1234567"
                required
                maxLength={20}
              />
            </Field>
            <Field id="mcNumber" label="MC number (optional)">
              <Input id="mcNumber" name="mcNumber" placeholder="e.g. MC-987654" maxLength={20} />
            </Field>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <Field id="truckType" label="Truck type" required>
              <Select value={truckType} onValueChange={setTruckType}>
                <SelectTrigger id="truckType" aria-label="Truck type">
                  <SelectValue placeholder="Select truck type" />
                </SelectTrigger>
                <SelectContent>
                  {TRUCK_TYPES.map((t) => (
                    <SelectItem key={t.value} value={t.value}>
                      {t.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field id="truckCount" label="Number of trucks" required>
              <Input
                id="truckCount"
                name="truckCount"
                type="number"
                min={1}
                max={500}
                defaultValue={1}
                required
              />
            </Field>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <Field id="serviceArea" label="Service area" required>
              <Input
                id="serviceArea"
                name="serviceArea"
                placeholder="e.g. Atlanta metro, North GA"
                required
                maxLength={200}
              />
            </Field>
            <Field id="availability" label="Availability" required>
              <Select value={availability} onValueChange={setAvailability}>
                <SelectTrigger id="availability" aria-label="Availability">
                  <SelectValue placeholder="Select availability" />
                </SelectTrigger>
                <SelectContent>
                  {AVAILABILITY.map((a) => (
                    <SelectItem key={a.value} value={a.value}>
                      {a.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
          </div>

          <Field id="notes" label="Notes (optional)">
            <Textarea
              id="notes"
              name="notes"
              placeholder="Equipment details, insurance carrier, preferred materials, etc."
              rows={4}
              maxLength={1500}
            />
          </Field>

          <Button
            type="submit"
            disabled={submitting}
            size="lg"
            className="w-full bg-brand-green hover:bg-brand-green/90 text-navy shadow-[var(--shadow-glow)]"
          >
            {submitting ? "Submitting..." : "Register my trucks"}
          </Button>

          <p className="text-xs text-muted-foreground text-center">
            By submitting, you agree to be contacted by our dispatch team about hauling opportunities.
          </p>
        </motion.form>
      </div>
    </section>
  );
}

function Field({
  id,
  label,
  required,
  children,
}: {
  id: string;
  label: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id} className="text-sm font-medium text-navy">
        {label} {required && <span className="text-brand-green">*</span>}
      </Label>
      {children}
    </div>
  );
}

function Perk({
  icon,
  title,
  body,
}: {
  icon: React.ReactNode;
  title: string;
  body: string;
}) {
  return (
    <div className="flex items-start gap-3 p-4 rounded-2xl bg-card border border-border shadow-[var(--shadow-card)]">
      <span
        className="grid place-items-center w-10 h-10 rounded-xl text-white shrink-0"
        style={{ background: "var(--gradient-accent)" }}
      >
        {icon}
      </span>
      <div>
        <div className="text-sm font-semibold text-navy">{title}</div>
        <div className="text-sm text-muted-foreground">{body}</div>
      </div>
    </div>
  );
}
