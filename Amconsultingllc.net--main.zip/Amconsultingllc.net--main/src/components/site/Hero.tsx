import { motion } from "framer-motion";
import { Phone, ArrowRight, Truck, Route as RouteIcon, Clock, ShieldCheck } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { CONTACT } from "@/lib/contact";
import heroVideo from "@/assets/hero.mp4.asset.json";
import { Button } from "@/components/ui/button";

export function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-[100svh] flex items-center overflow-hidden isolate pt-16"
    >
      {/* Background */}
      <div className="absolute inset-0 -z-10">
        <video
          src={heroVideo.url}
          autoPlay
          muted
          loop
          playsInline
          preload="auto"
          aria-hidden="true"
          className="w-full h-full object-cover"
        />

        {/* Soft blue tint so the video stays visible */}
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(180deg, color-mix(in oklab, var(--navy) 25%, transparent) 0%, color-mix(in oklab, var(--navy-deep) 20%, transparent) 100%)",
            mixBlendMode: "multiply",
          }}
        />
        {/* Cyan light wash for brand glow */}
        <div
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(60% 80% at 80% 20%, color-mix(in oklab, var(--brand-green) 18%, transparent), transparent 70%)",
          }}
        />
        {/* Left-side readability gradient for hero copy */}
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(100deg, color-mix(in oklab, var(--navy-deep) 75%, transparent) 0%, color-mix(in oklab, var(--navy) 35%, transparent) 45%, transparent 70%)",
          }}
        />
        {/* animated route line */}
        <svg
          aria-hidden
          className="absolute bottom-10 left-0 right-0 w-full h-24 opacity-70"
          viewBox="0 0 1200 100"
          preserveAspectRatio="none"
        >
          <motion.path
            d="M0,60 C200,20 400,90 600,55 C800,20 1000,80 1200,40"
            fill="none"
            stroke="var(--brand-green)"
            strokeWidth="2"
            strokeDasharray="8 10"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 1 }}
            transition={{ duration: 2.5, ease: "easeInOut" }}
          />
        </svg>
      </div>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid lg:grid-cols-12 gap-10 items-center py-20">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="lg:col-span-7 text-white"
        >
          <span className="inline-flex items-center gap-2 rounded-full glass-dark px-3 py-1.5 text-xs font-semibold text-brand-green-soft uppercase tracking-wider">
            <span className="w-1.5 h-1.5 rounded-full bg-brand-green animate-pulse" />
            {CONTACT.serviceArea}
          </span>

          <h1 className="mt-5 text-4xl sm:text-5xl lg:text-6xl font-extrabold leading-[1.05] text-white">
            Professional Dump Truck{" "}
            <span className="text-gradient-brand">Dispatching Services</span>
          </h1>

          <p className="mt-5 text-lg text-white/80 max-w-xl">
            Keeping trucks moving. Keeping projects on schedule. We connect drivers with loads,
            manage schedules, and coordinate dependable hauling for contractors and dump truck
            owners.
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <Button
              asChild
              size="lg"
              className="bg-brand-green hover:bg-brand-green/90 text-navy shadow-[var(--shadow-glow)]"
            >
              <Link to="/contact">
                Request Dispatch Services <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="bg-white/5 border-white/30 text-white hover:bg-white/10 hover:text-white"
            >
              <a href={`tel:${CONTACT.phoneE164}`}>
                <Phone className="mr-2 w-4 h-4" /> Call {CONTACT.phone}
              </a>
            </Button>
          </div>

          <div className="mt-10 flex flex-wrap items-center gap-x-8 gap-y-3 text-sm text-white/70">
            <div className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-brand-green" /> Fully vetted drivers</div>
            <div className="flex items-center gap-2"><Clock className="w-4 h-4 text-brand-green" /> 24/7 dispatch support</div>
            <div className="flex items-center gap-2"><RouteIcon className="w-4 h-4 text-brand-green" /> Nationwide coordination</div>
          </div>
        </motion.div>

        {/* Floating stat cards */}
        <div className="lg:col-span-5 relative h-[420px] hidden lg:block">
          <FloatingCard
            delay={0.2}
            className="absolute top-0 right-6 w-64"
            icon={<Truck className="w-5 h-5" />}
            label="Active Loads Today"
            value="42"
            trend="+12%"
          />
          <FloatingCard
            delay={0.4}
            className="absolute top-40 left-0 w-72"
            icon={<Clock className="w-5 h-5" />}
            label="On-Time Delivery"
            value="98%"
            trend="last 30 days"
          />
          <FloatingCard
            delay={0.6}
            className="absolute bottom-0 right-0 w-60"
            icon={<RouteIcon className="w-5 h-5" />}
            label="Routes Optimized"
            value="1.2k"
            trend="this month"
          />
        </div>
      </div>
    </section>
  );
}

function FloatingCard({
  className,
  icon,
  label,
  value,
  trend,
  delay = 0,
}: {
  className?: string;
  icon: React.ReactNode;
  label: string;
  value: string;
  trend: string;
  delay?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, delay }}
      className={`glass-dark rounded-xl p-4 text-white shadow-[var(--shadow-elevated)] ${className}`}
    >
      <motion.div
        animate={{ y: [0, -6, 0] }}
        transition={{ duration: 4 + delay, repeat: Infinity, ease: "easeInOut" }}
      >
        <div className="flex items-center gap-2 text-brand-green-soft text-xs font-semibold uppercase tracking-wider">
          <span className="grid place-items-center w-7 h-7 rounded-md bg-brand-green/20 text-brand-green">
            {icon}
          </span>
          {label}
        </div>
        <div className="mt-3 flex items-baseline gap-2">
          <span className="text-3xl font-extrabold font-display">{value}</span>
          <span className="text-xs text-white/60">{trend}</span>
        </div>
      </motion.div>
    </motion.div>
  );
}
