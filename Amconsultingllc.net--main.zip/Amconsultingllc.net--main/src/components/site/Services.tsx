import { motion } from "framer-motion";
import {
  Truck,
  PackageCheck,
  CalendarClock,
  Route,
  ClipboardList,
  HardHat,
} from "lucide-react";

const services = [
  {
    icon: Truck,
    title: "Dump Truck Dispatching",
    desc: "We coordinate loads, routes, and schedules to help truck owners maximize productivity and reduce downtime.",
  },
  {
    icon: HardHat,
    title: "Construction Hauling Support",
    desc: "We assist contractors in securing dependable hauling solutions for construction projects.",
  },
  {
    icon: PackageCheck,
    title: "Load Coordination",
    desc: "We match available trucks with hauling opportunities and manage communication throughout the job.",
  },
  {
    icon: Route,
    title: "Logistics Management",
    desc: "From scheduling to job tracking, we help streamline hauling operations.",
  },
  {
    icon: CalendarClock,
    title: "Project Scheduling",
    desc: "Phased hauling schedules aligned with your build plan so equipment never sits idle.",
  },
  {
    icon: ClipboardList,
    title: "Transportation Consulting",
    desc: "Process audits, rate benchmarking, and operations strategy for hauling-heavy contractors.",
  },
];

export function Services() {
  return (
    <section id="services" className="relative py-24 sm:py-32 bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeader
          eyebrow="What we do"
          title="Dispatching, hauling & logistics support"
          subtitle="Core services that keep dump trucks loaded, contractors stocked, and projects on schedule."
        />

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => (
            <motion.article
              key={s.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className="group relative rounded-2xl bg-card p-6 border border-border shadow-[var(--shadow-card)] hover:shadow-[var(--shadow-elevated)] hover:-translate-y-1 transition-all duration-300"
            >
              <div
                className="absolute inset-x-0 top-0 h-1 rounded-t-2xl opacity-0 group-hover:opacity-100 transition-opacity"
                style={{ background: "var(--gradient-accent)" }}
              />
              <div
                className="grid place-items-center w-12 h-12 rounded-xl text-white"
                style={{ background: "var(--gradient-hero)" }}
              >
                <s.icon className="w-6 h-6" />
              </div>
              <h3 className="mt-5 text-lg font-bold text-navy">{s.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}

export function SectionHeader({
  eyebrow,
  title,
  subtitle,
  light = false,
}: {
  eyebrow: string;
  title: string;
  subtitle?: string;
  light?: boolean;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="max-w-2xl"
    >
      <span
        className={`text-xs font-bold uppercase tracking-[0.18em] ${
          light ? "text-brand-green-soft" : "text-brand-green"
        }`}
      >
        {eyebrow}
      </span>
      <h2
        className={`mt-3 text-3xl sm:text-4xl lg:text-5xl font-extrabold leading-[1.05] ${
          light ? "text-white" : "text-navy"
        }`}
      >
        {title}
      </h2>
      {subtitle && (
        <p className={`mt-4 text-base sm:text-lg ${light ? "text-white/75" : "text-muted-foreground"}`}>
          {subtitle}
        </p>
      )}
    </motion.div>
  );
}
