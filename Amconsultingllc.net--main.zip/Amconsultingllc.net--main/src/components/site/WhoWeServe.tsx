import { motion } from "framer-motion";
import { Truck, Users, HardHat, Shovel, Trees, Building2 } from "lucide-react";
import { SectionHeader } from "./Services";

const audiences = [
  { icon: Truck, title: "Independent Dump Truck Owners" },
  { icon: Users, title: "Fleet Owners" },
  { icon: HardHat, title: "Construction Contractors" },
  { icon: Shovel, title: "Excavation Companies" },
  { icon: Trees, title: "Landscaping Companies" },
  { icon: Building2, title: "Site Development Projects" },
];

export function WhoWeServe() {
  return (
    <section className="relative py-24 sm:py-32 bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeader
          eyebrow="Who we serve"
          title="Built for hauling — top to bottom"
          subtitle="From single-truck owner-operators to multi-site contractors, we keep loads moving."
        />

        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {audiences.map((a, i) => (
            <motion.div
              key={a.title}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.4, delay: i * 0.06 }}
              className="flex items-center gap-4 rounded-2xl bg-card p-5 border border-border shadow-[var(--shadow-card)] hover:border-brand-green/60 hover:shadow-[var(--shadow-elevated)] transition-all"
            >
              <span
                className="grid place-items-center w-12 h-12 rounded-xl text-white shrink-0"
                style={{ background: "var(--gradient-hero)" }}
              >
                <a.icon className="w-6 h-6" />
              </span>
              <span className="text-base font-semibold text-navy">{a.title}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
