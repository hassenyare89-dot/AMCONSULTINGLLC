import { motion } from "framer-motion";
import { Award, Headphones, Radio, Timer, Zap, Users } from "lucide-react";
import { SectionHeader } from "./Services";

const items = [
  { icon: Headphones, title: "Experienced Dispatch Support", desc: "Seasoned dispatchers who understand hauling, routing, and project flow." },
  { icon: Radio, title: "Reliable Load Coordination", desc: "We match the right trucks with the right loads — every shift, every site." },
  { icon: Zap, title: "Fast Communication", desc: "Quick responses to drivers, contractors, and project managers." },
  { icon: Timer, title: "Efficient Scheduling", desc: "Schedules built to keep trucks rolling and projects on track." },
  { icon: Award, title: "Professional Service", desc: "White-glove coordination from first call to final load." },
  { icon: Users, title: "Dedicated Customer Support", desc: "A real team you can reach — committed to your project's success." },
];

export function WhyUs() {
  return (
    <section className="relative py-24 sm:py-32 text-white overflow-hidden" style={{ background: "var(--gradient-hero)" }}>
      <div
        aria-hidden
        className="absolute inset-0 opacity-30"
        style={{
          backgroundImage:
            "radial-gradient(circle at 20% 20%, color-mix(in oklab, var(--brand-green) 40%, transparent), transparent 40%), radial-gradient(circle at 80% 60%, color-mix(in oklab, var(--brand-green) 25%, transparent), transparent 45%)",
        }}
      />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeader
          eyebrow="Why choose us"
          title="Why choose AM Consulting and Hauling?"
          subtitle="We bring structure, accountability, and speed to every dispatch decision."
          light
        />

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((it, i) => (
            <motion.div
              key={it.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: i * 0.07 }}
              className="glass-dark rounded-2xl p-6 hover:-translate-y-1 transition-transform"
            >
              <div className="grid place-items-center w-11 h-11 rounded-lg bg-brand-green/20 text-brand-green">
                <it.icon className="w-6 h-6" />
              </div>
              <h3 className="mt-4 text-lg font-bold">{it.title}</h3>
              <p className="mt-2 text-sm text-white/75 leading-relaxed">{it.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
