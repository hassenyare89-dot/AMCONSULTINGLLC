import { motion } from "framer-motion";
import { MessageSquare, ClipboardCheck, Radio, Flag } from "lucide-react";
import { SectionHeader } from "./Services";

const steps = [
  {
    icon: MessageSquare,
    title: "Contact Us",
    desc: "Reach out with your hauling or dispatching needs.",
  },
  {
    icon: ClipboardCheck,
    title: "Coordination",
    desc: "We align available trucks with your project requirements.",
  },
  {
    icon: Radio,
    title: "Dispatch",
    desc: "Loads are scheduled and dispatched efficiently.",
  },
  {
    icon: Flag,
    title: "On Schedule",
    desc: "Projects stay on schedule with dependable hauling support.",
  },
];

export function Process() {
  return (
    <section id="process" className="relative py-24 sm:py-32 bg-background overflow-hidden">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeader
          eyebrow="How it works"
          title="A clear, four-step process"
          subtitle="From the first call to the final load, you always know what's happening."
        />

        <div className="mt-16 relative">
          {/* connecting line */}
          <div className="hidden lg:block absolute top-10 left-0 right-0 h-px route-dash" />

          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {steps.map((s, i) => (
              <motion.div
                key={s.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="relative text-center"
              >
                <div className="relative mx-auto w-20 h-20">
                  <div
                    className="absolute inset-0 rounded-full opacity-25 blur-xl"
                    style={{ background: "var(--gradient-accent)" }}
                  />
                  <div
                    className="relative grid place-items-center w-20 h-20 rounded-full text-white border-4 border-background"
                    style={{ background: "var(--gradient-hero)" }}
                  >
                    <s.icon className="w-8 h-8" />
                    <span className="absolute -top-2 -right-2 grid place-items-center w-7 h-7 rounded-full bg-brand-green text-navy text-xs font-bold shadow-[var(--shadow-glow)]">
                      {i + 1}
                    </span>
                  </div>
                </div>
                <h3 className="mt-5 text-lg font-bold text-navy">{s.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
