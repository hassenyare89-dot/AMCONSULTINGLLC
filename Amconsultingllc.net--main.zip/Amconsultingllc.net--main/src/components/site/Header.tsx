import { useEffect, useState } from "react";
import { Menu, X, Phone } from "lucide-react";
import { Link, useRouterState } from "@tanstack/react-router";
import { CONTACT } from "@/lib/contact";
import { Logo } from "./Logo";
import { Button } from "@/components/ui/button";

const NAV = [
  { label: "Home", to: "/" },
  { label: "Services", to: "/services" },
  { label: "About", to: "/about" },
  { label: "Process", to: "/process" },
  { label: "Drivers", to: "/drivers" },
  { label: "Contact", to: "/contact" },
] as const;

const MOBILE_NAV_ID = "primary-mobile-nav";

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const isHome = pathname === "/";

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  const solid = scrolled || !isHome;
  const linkFocus = "focus-visible:focus-brand rounded-md";
  const linkActive = "underline decoration-brand-green decoration-2 underline-offset-[6px]";

  return (
    <>
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-[60] focus:px-4 focus:py-2 focus:rounded-md focus:bg-navy focus:text-white"
      >
        Skip to main content
      </a>
      <header
        className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
          solid ? "glass-panel shadow-[0_8px_30px_-20px_rgba(7,42,108,0.35)]" : "bg-transparent"
        }`}
      >
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Logo light={!solid} />

          <nav className="hidden md:flex items-center gap-1" aria-label="Primary">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                activeOptions={{ exact: true }}
                activeProps={{ className: linkActive, "aria-current": "page" }}
                className={`px-3 py-2 text-sm font-medium rounded-md transition-colors hover:underline hover:decoration-brand-green hover:decoration-2 hover:underline-offset-[6px] ${linkFocus} ${
                  solid ? "text-navy" : "text-white"
                }`}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-2">
            <a
              href={`tel:${CONTACT.phoneE164}`}
              aria-label={`Call ${CONTACT.company} at ${CONTACT.phone}`}
              className={`inline-flex items-center gap-2 text-sm font-semibold rounded-md px-2 py-1 transition-colors hover:underline hover:decoration-brand-green hover:decoration-2 hover:underline-offset-[6px] active:opacity-80 aria-disabled:opacity-50 aria-disabled:pointer-events-none ${linkFocus} ${
                solid ? "text-navy" : "text-white"
              }`}
            >
              <Phone className="w-4 h-4" aria-hidden="true" /> {CONTACT.phone}
            </a>
            <Button asChild className="bg-brand-green hover:bg-brand-green/90 text-navy shadow-[var(--shadow-glow)]">
              <Link to="/contact">Request Dispatch</Link>
            </Button>
          </div>

          <button
            type="button"
            aria-label={open ? "Close navigation menu" : "Open navigation menu"}
            aria-expanded={open}
            aria-controls={MOBILE_NAV_ID}
            className={`md:hidden inline-flex items-center justify-center w-11 h-11 rounded-md ${linkFocus} ${
              solid ? "text-navy" : "text-white"
            }`}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="w-6 h-6" aria-hidden="true" /> : <Menu className="w-6 h-6" aria-hidden="true" />}
          </button>
        </div>

        <nav
          id={MOBILE_NAV_ID}
          aria-label="Mobile primary"
          hidden={!open}
          className="md:hidden glass-panel border-t border-border"
        >
          <div className="px-4 py-4 flex flex-col gap-1">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                activeOptions={{ exact: true }}
                activeProps={{ "aria-current": "page", className: linkActive }}
                className={`px-3 py-3 rounded-md text-navy font-medium hover:bg-secondary hover:underline hover:decoration-brand-green hover:decoration-2 hover:underline-offset-[6px] active:bg-secondary/70 aria-disabled:opacity-50 aria-disabled:pointer-events-none min-h-11 flex items-center transition-colors ${linkFocus}`}
              >
                {item.label}
              </Link>
            ))}
            <Button asChild className="mt-2 bg-brand-green hover:bg-brand-green/90 text-navy">
              <Link to="/contact" onClick={() => setOpen(false)}>
                Request Dispatch
              </Link>
            </Button>
          </div>
        </nav>
      </header>
    </>
  );
}
