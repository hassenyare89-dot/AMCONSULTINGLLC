import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

export type DriverRow = {
  id: string;
  created_at: string;
  owner_name: string;
  company_name: string | null;
  email: string;
  phone: string;
  dot_number: string;
  mc_number: string | null;
  truck_type: string;
  truck_count: number;
  service_area: string;
  availability: string;
  notes: string | null;
  status: string;
};

async function assertAdmin(supabase: any, userId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "admin")
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden: admin role required");
}

export const getAdminStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: hasAdmins } = await supabaseAdmin
      .from("user_roles")
      .select("id", { head: true, count: "exact" })
      .eq("role", "admin");
    const { data: mine } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", context.userId)
      .eq("role", "admin")
      .maybeSingle();
    return {
      isAdmin: !!mine,
      adminExists: !!hasAdmins,
      email: (context.claims as any)?.email ?? null,
    };
  });

export const claimFirstAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase.rpc("claim_first_admin");
    if (error) throw new Error(error.message);
    return { claimed: !!data };
  });

const ListInput = z.object({
  search: z.string().optional().default(""),
  availability: z.string().optional().default(""),
  truckType: z.string().optional().default(""),
  serviceArea: z.string().optional().default(""),
  limit: z.number().int().min(1).max(2000).optional().default(500),
});

export const listDrivers = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ListInput.parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    let q = supabaseAdmin
      .from("driver_registrations")
      .select(
        "id,created_at,owner_name,company_name,email,phone,dot_number,mc_number,truck_type,truck_count,service_area,availability,notes,status",
      )
      .order("created_at", { ascending: false })
      .limit(data.limit);

    if (data.availability) q = q.eq("availability", data.availability);
    if (data.truckType) q = q.eq("truck_type", data.truckType);
    if (data.serviceArea) q = q.ilike("service_area", `%${data.serviceArea}%`);
    if (data.search) {
      const s = data.search.replace(/,/g, " ").trim();
      q = q.or(
        [
          `owner_name.ilike.%${s}%`,
          `company_name.ilike.%${s}%`,
          `email.ilike.%${s}%`,
          `phone.ilike.%${s}%`,
          `dot_number.ilike.%${s}%`,
          `mc_number.ilike.%${s}%`,
        ].join(","),
      );
    }
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return { rows: (rows ?? []) as DriverRow[] };
  });

const StatusInput = z.object({
  id: z.string().uuid(),
  status: z.enum(["new", "reviewed", "approved", "rejected"]),
});

export const updateDriverStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => StatusInput.parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("driver_registrations")
      .update({ status: data.status })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
